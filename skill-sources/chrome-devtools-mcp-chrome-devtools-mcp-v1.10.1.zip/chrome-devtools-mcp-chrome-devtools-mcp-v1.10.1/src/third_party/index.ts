/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import 'core-js/modules/es.promise.with-resolvers.js';
import 'core-js/modules/es.set.union.v2.js';
import 'core-js/proposals/iterator-helpers.js';

import type {Flags, OutputMode, Result, RunnerResult} from 'lighthouse';
import type {Page} from 'puppeteer-core';
import {z as zod} from 'zod';

export type {Flags, Result, RunnerResult, OutputMode};

export type {Options as YargsOptions} from 'yargs';
export {default as yargs} from 'yargs';
export {hideBin} from 'yargs/helpers';
export {default as semver} from 'semver';
export {McpServer, type RegisteredTool} from '@modelcontextprotocol/server';
export {
  StdioServerTransport,
  serveStdio,
} from '@modelcontextprotocol/server/stdio';
export type {Transport} from '@modelcontextprotocol/server';
export {StdioClientTransport} from '@modelcontextprotocol/client/stdio';
export {Client, type ClientCapabilities} from '@modelcontextprotocol/client';
export {
  type CallToolResult,
  type ImageContent,
  type TextContent,
  type Tool,
  type Root,
} from '@modelcontextprotocol/server';
export {
  SetLevelRequestSchema,
  ListRootsRequestSchema,
  RootsListChangedNotificationSchema,
  ListRootsResultSchema,
} from '@modelcontextprotocol/core';
export {zod};
export type ShapeOutput<T extends zod.ZodRawShape> = zod.output<
  zod.ZodObject<T>
>;

export {default as ajv} from 'ajv';
export {
  Dialog,
  ElementHandle,
  Locator,
  PredefinedNetworkConditions,
  KnownDevices,
  CDPSessionEvent,
  ScreenRecorder,
  TimeoutError,
} from 'puppeteer-core';
export {default as puppeteer} from 'puppeteer-core';
export type * from 'puppeteer-core';
export {PipeTransport} from 'puppeteer-core/internal/node/PipeTransport.js';
export {CdpBrowser} from 'puppeteer-core/internal/cdp/Browser.js';
export {CdpFrame} from 'puppeteer-core/internal/cdp/Frame.js';
export {CdpPage} from 'puppeteer-core/internal/cdp/Page.js';
export {CdpExtension} from 'puppeteer-core/internal/cdp/Extension.js';
export type {CdpWebWorker} from 'puppeteer-core/internal/cdp/WebWorker.js';
export type {Realm} from 'puppeteer-core/internal/api/Realm.js';
export {FrameEvent} from 'puppeteer-core/internal/api/Frame.js';
export type {JSONSchema7, JSONSchema7Definition} from 'json-schema';
export {Mutex} from 'puppeteer-core/internal/util/Mutex.js';
export {
  DisposableStack,
  AsyncDisposableStack,
  SuppressedError,
} from 'puppeteer-core/internal/util/disposable.js';
export {
  resolveDefaultUserDataDir,
  detectBrowserPlatform,
  Browser as BrowserEnum,
  type ChromeReleaseChannel as BrowsersChromeReleaseChannel,
} from '@puppeteer/browsers';
export async function getToonEncode(): Promise<(val: unknown) => string> {
  const {encode} = await import('@toon-format/toon');
  return encode;
}
export async function getGcfEncode(): Promise<(val: unknown) => string> {
  const {encodeGeneric} = await import('@blackwell-systems/gcf');
  return encodeGeneric;
}

import {
  snapshot as snapshotImpl,
  navigation as navigationImpl,
  generateReport as generateReportImpl,
} from './lighthouse-devtools-mcp-bundle.js';

export const lighthouseRunner = {
  snapshot: snapshotImpl as (
    page: Page,
    options: {flags?: Flags},
  ) => Promise<RunnerResult>,
  navigation: navigationImpl as (
    page: Page,
    url: string,
    options: {flags?: Flags},
  ) => Promise<RunnerResult>,
};

export const generateReport = generateReportImpl as (
  lhr: Result,
  format: string,
) => string;

export * as DevTools from '../../third_party/devtools-frontend/mcp/mcp.js';
