/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import type {ParsedArguments} from '../config/mcp-options.js';
import type {
  HeapSnapshotAggregateData,
  HeapSnapshotClassDiff,
  HeapSnapshotDetailedClassDiff,
  DuplicateStringGroup,
  HeapEdgesQueryOptions,
  HeapQueryOptions,
} from '../processors/HeapSnapshotManager.js';
import type {McpPage} from '../McpPage.js';
import type {DevToolsCommentBridge} from '../devtools/DevToolsCommentBridge.js';
import type {CssFormatterOptions} from '../formatters/CssFormatter.js';
import {zod} from '../third_party/index.js';
import type {
  Dialog,
  ElementHandle,
  Extension,
  GetPWAStateOptions,
  InstallPWAOptions,
  LaunchPWAOptions,
  PWAState,
  ScreenRecorder,
  UninstallPWAOptions,
  Viewport,
  DevTools,
  Protocol,
  Page,
} from '../third_party/index.js';
import type {InsightName, TraceResult} from '../processors/PerformanceTrace.js';
import type {
  TextSnapshotNode,
  GeolocationOptions,
  ExtensionServiceWorker,
  CD4ACommentThread,
} from '../types.js';
import type {PaginationOptions} from '../types.js';
import type {
  WaitForEventsResult,
  DialogAction,
} from '../utils/WaitForHelper.js';

import type {ToolCategory} from './categories.js';
import type {ToolGroups} from './thirdPartyDeveloper.js';

export type FileVerificationOption =
  | true
  | {
      local?: boolean;
      remote?: boolean;
    };

type AllKeys<T> = T extends unknown ? keyof T : never;

type ExtractSchemaField<Schema, K extends PropertyKey> = Schema extends unknown
  ? K extends keyof Schema
    ? Exclude<Schema[K], undefined>
    : never
  : never;

export type MergeSchema<Schema extends zod.ZodRawShape> = {
  [K in AllKeys<Schema>]: K extends keyof Schema
    ? undefined extends Schema[K]
      ? zod.ZodOptional<ExtractSchemaField<Schema, K>>
      : Schema[K]
    : zod.ZodOptional<ExtractSchemaField<Schema, K>>;
};

export interface BaseToolDefinition<
  Schema extends zod.ZodRawShape = zod.ZodRawShape,
> {
  name: string;
  description: string;
  annotations: {
    title?: string;
    category: ToolCategory;
    /**
     * If true, the tool does not modify its environment.
     */
    readOnlyHint: boolean;
    conditions?: string[];
  };
  schema: Schema;
  blockedByDialog: boolean;
  verifyFilesSchema: Partial<
    Record<keyof MergeSchema<Schema>, FileVerificationOption>
  >;
}

export interface ToolDefinition<
  Schema extends zod.ZodRawShape = zod.ZodRawShape,
> extends BaseToolDefinition<Schema> {
  schema: Schema;
  handler(
    request: Request<Schema>,
    response: Response,
    context: Context,
  ): Promise<void>;
}

export type SchemaType<T extends zod.ZodRawShape> = zod.output<
  zod.ZodObject<MergeSchema<T>>
>;

export interface Request<Schema extends zod.ZodRawShape> {
  params: SchemaType<Schema>;
}

export interface ImageContentData {
  data: string;
  mimeType: string;
}

export interface SnapshotParams {
  verbose?: boolean;
  filePath?: string;
}

export interface LighthouseData {
  summary: {
    mode: string;
    device: string;
    url?: string;
    scores: Array<{
      id: string;
      title: string;
      score: number | null;
    }>;
    audits: {
      failed: number;
      passed: number;
    };
    timing: {
      total: number;
    };
  };
  reports: string[];
}

export interface DevToolsData {
  cdpRequestId?: string;
  cdpBackendNodeId?: number;
}

export interface Response {
  appendResponseLine(value: string): void;
  setHeapSnapshotAggregates(
    aggregateData: HeapSnapshotAggregateData,
    options?: PaginationOptions,
  ): void;
  setHeapSnapshotStats(
    stats: DevTools.HeapSnapshotModel.HeapSnapshotModel.Statistics,
    staticData: DevTools.HeapSnapshotModel.HeapSnapshotModel.StaticData | null,
    nativeContextSizes: DevTools.HeapSnapshotModel.HeapSnapshotModel.NativeContextSizes,
    retainedByContextSummary: DevTools.HeapSnapshotModel.HeapSnapshotModel.RetainedByContextSummary,
  ): void;
  setHeapSnapshotNodes(
    nodes: DevTools.HeapSnapshotModel.HeapSnapshotModel.ItemsRange,
    options?: PaginationOptions,
  ): void;
  setHeapSnapshotDuplicateStrings(
    duplicateStrings: DuplicateStringGroup[],
    options?: PaginationOptions,
  ): void;
  setHeapSnapshotRetainingPaths(
    retainingPaths: DevTools.HeapSnapshotModel.HeapSnapshotModel.RetainingPaths,
  ): void;
  setHeapSnapshotDominators(
    dominators: DevTools.HeapSnapshotModel.HeapSnapshotModel.DominatorChain,
  ): void;
  setHeapSnapshotClassDiffs(classDiffs: HeapSnapshotClassDiff[]): void;
  setHeapSnapshotDetailedClassDiff(
    detailedClassDiff: HeapSnapshotDetailedClassDiff,
  ): void;
  setHeapSnapshotObjectDetails(
    objectInfo: DevTools.HeapSnapshotModel.HeapSnapshotModel.ObjectInfo,
  ): void;
  setIncludePages(value: boolean): void;
  setIncludeNetworkRequests(
    value: boolean,
    options?: PaginationOptions & {
      resourceTypes?: string[];
      includePreservedRequests?: boolean;
      networkRequestIdInDevToolsUI?: number;
    },
  ): void;
  setIncludeConsoleData(
    value: boolean,
    options?: PaginationOptions & {
      types?: string[];
      includePreservedMessages?: boolean;
      includeStackTraces?: boolean;
      serviceWorkerId?: string;
    },
  ): void;
  setIncludeCssStyles(
    matchedStyles: MatchedStyles,
    options: CssFormatterOptions & PaginationOptions,
  ): void;
  includeSnapshot(params?: SnapshotParams): void;
  attachImage(value: ImageContentData): void;
  attachNetworkRequest(
    reqId: number,
    options?: {requestFilePath?: string; responseFilePath?: string},
  ): void;
  attachConsoleMessage(msgid: number): void;
  // Allows re-using DevTools data queried by some tools.
  attachDevToolsData(data: DevToolsData): void;
  setTabId(tabId: string): void;
  attachTraceSummary(trace: TraceResult): void;
  attachTraceInsight(
    trace: TraceResult,
    insightSetId: string,
    insightName: InsightName,
  ): void;
  setListExtensions(): void;
  attachLighthouseResult(result: LighthouseData): void;
  setListThirdPartyDeveloperTools(): void;
  setListWebMcpTools(): void;
  attachWaitForResult(result: WaitForEventsResult): void;
  setDevToolsComments(threads: CD4ACommentThread[]): void;
}

export type SupportedExtensions =
  | '.png'
  | '.jpeg'
  | '.webp'
  | '.json'
  | '.network-response'
  | '.network-request'
  | '.html'
  | '.txt'
  | '.csv'
  | '.gz';

/**
 * Only add methods used by tools/*.
 */
export type Context = Readonly<{
  installPWA(options: InstallPWAOptions): Promise<string>;
  uninstallPWA(options: UninstallPWAOptions): Promise<void>;
  launchPWA(options: LaunchPWAOptions): Promise<Page>;
  getPWAState(options: GetPWAStateOptions): Promise<PWAState>;
  ensureExtension<Extension extends `.${string}`>(
    filePath: string,
    extension: Extension,
  ): Promise<`${string}${Extension}`>;
  isRunningPerformanceTrace(): boolean;
  setIsRunningPerformanceTrace(x: boolean): void;
  isCruxEnabled(): boolean;
  recordedTraces(): TraceResult[];
  storeTraceRecording(result: TraceResult): void;
  getPageById(pageId: number): ContextPage;
  newPage(
    background?: boolean,
    isolatedContextName?: string,
  ): Promise<ContextPage>;
  closePage(pageId: number): Promise<void>;
  selectPage(page: ContextPage): void;
  saveTemporaryFile(
    data: Uint8Array<ArrayBufferLike>,
    filename: string,
  ): Promise<{filepath: string}>;
  saveFile(
    data: Uint8Array<ArrayBufferLike>,
    clientProvidedFilePath: string,
    extension: SupportedExtensions,
  ): Promise<{filename: string}>;

  getScreenRecorder(): {recorder: ScreenRecorder; filePath: string} | null;
  setScreenRecorder(
    data: {recorder: ScreenRecorder; filePath: string} | null,
  ): void;
  installExtension(path: string): Promise<string>;
  uninstallExtension(id: string): Promise<void>;
  triggerExtensionAction(id: string): Promise<void>;
  listExtensions(): Promise<Map<string, Extension>>;
  getExtension(id: string): Promise<Extension | undefined>;
  getSelectedMcpPage(): McpPage;
  getExtensionServiceWorkers(): ExtensionServiceWorker[];
  getExtensionServiceWorkerId(
    extensionServiceWorker: ExtensionServiceWorker,
  ): string | undefined;
  getHeapSnapshotAggregates(
    filePath: string,
    filterName?: string,
    objectId?: number,
  ): Promise<HeapSnapshotAggregateData>;
  getHeapSnapshotDuplicateStrings(
    filePath: string,
  ): Promise<DuplicateStringGroup[]>;
  getHeapSnapshotStats(
    filePath: string,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.Statistics>;
  getHeapSnapshotStaticData(
    filePath: string,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.StaticData | null>;
  getHeapSnapshotNativeContextSizes(
    filePath: string,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.NativeContextSizes>;
  getHeapSnapshotRetainedByContextSummary(
    filePath: string,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.RetainedByContextSummary>;
  getHeapSnapshotNodesById(
    filePath: string,
    id: number,
    filterName?: string,
    objectId?: number,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.ItemsRange>;
  getHeapSnapshotRetainers(
    filePath: string,
    nodeId: number,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.ItemsRange>;
  getHeapSnapshotObjectDetails(
    filePath: string,
    nodeId: number,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.ObjectInfo>;
  closeHeapSnapshot(filePath: string): Promise<boolean>;
  getHeapSnapshotRetainingPaths(
    filePath: string,
    nodeId: number,
    maxDepth?: number,
    maxNodes?: number,
    maxSiblings?: number,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.RetainingPaths>;
  getHeapSnapshotDominators(
    filePath: string,
    nodeId: number,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.DominatorChain>;
  getHeapSnapshotEdges(
    filePath: string,
    nodeId: number,
    options?: HeapEdgesQueryOptions,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.ItemsRange>;
  getHeapSnapshotClassDiffs(
    baseFilePath: string,
    currentFilePath: string,
  ): Promise<HeapSnapshotClassDiff[]>;
  getHeapSnapshotDetailedClassDiff(
    baseFilePath: string,
    currentFilePath: string,
    classIndex: number,
  ): Promise<HeapSnapshotDetailedClassDiff>;
  queryHeapSnapshotObjects(
    filePath: string,
    options: HeapQueryOptions,
  ): Promise<DevTools.HeapSnapshotModel.HeapSnapshotModel.ItemsRange>;
}>;

export type MatchedStyles = DevTools.CSSMatchedStyles.CSSMatchedStyles;

/**
 * Only add methods used by tools/*.
 */
export type ContextPage = Readonly<{
  readonly pptrPage: Page;
  readonly cpuThrottlingRate: number;
  readonly networkConditions: string | null;
  getAXNodeByUid(uid: string): TextSnapshotNode | undefined;
  getElementByUid(uid: string): Promise<ElementHandle<Element>>;
  getMatchedStylesForUid(uid: string): Promise<MatchedStyles>;

  /**
   * Returns a reqid for a cdpRequestId.
   */
  resolveCdpRequestId(cdpRequestId: string): number | undefined;
  resolveReqidToCdpRequestId(reqid: number): string | undefined;
  resolveBackendNodeId(backendNodeId: number): Promise<string | undefined>;
  resolveUidToBackendNodeId(
    uid: string,
  ): Promise<{backendNodeId: number; targetId?: string} | undefined>;

  getDialog(): Dialog | undefined;
  clearDialog(): void;
  throwIfDialogOpen(): void;
  waitForEventsAfterAction(
    action: (signal: AbortSignal) => Promise<unknown>,
    options?: {
      timeout?: number;
      waitForStableDom?: boolean;
      handleDialog?:
        DialogAction | Partial<Record<Protocol.Page.DialogType, DialogAction>>;
    },
  ): Promise<WaitForEventsResult>;
  getThirdPartyDeveloperTools(): ToolGroups;

  executeThirdPartyDeveloperTool(
    toolName: string,
    params: Record<string, unknown>,
    response: Response,
  ): Promise<void>;
  getDevToolsData(): Promise<DevToolsData>;
  restoreEmulation(): Promise<void>;
  emulate(options: {
    networkConditions?: string;
    cpuThrottlingRate?: number;
    geolocation?: GeolocationOptions;
    userAgent?: string;
    colorScheme?: 'dark' | 'light' | 'auto';
    viewport?: Viewport;
  }): Promise<void>;
  waitForTextOnPage(text: string[], timeout?: number): Promise<Element>;
  getDevToolsPage(): Promise<Page | undefined>;
  openDevTools(): Promise<Page | undefined>;
  ensureDevToolsCommentBridge(
    devtoolsPage: Page,
  ): Promise<DevToolsCommentBridge>;
}>;

export function defineTool<Schema extends zod.ZodRawShape>(
  definition: (args: ParsedArguments) => ToolDefinition<Schema>,
): (args: ParsedArguments) => ToolDefinition<Schema> {
  return definition;
}

interface PageToolDefinition<
  Schema extends zod.ZodRawShape = zod.ZodRawShape,
> extends BaseToolDefinition<Schema> {
  handler(
    request: Request<Schema> & {page: ContextPage},
    response: Response,
    context: Context,
  ): Promise<void>;
}

export type DefinedPageTool<Schema extends zod.ZodRawShape = zod.ZodRawShape> =
  Omit<PageToolDefinition<Schema>, 'schema'> & {
    schema: Schema & Partial<typeof pageIdSchema>;
    pageScoped: true;
    handler(
      request: Request<Schema> & {page: ContextPage},
      response: Response,
      context: Context,
    ): Promise<void>;
  };

export function definePageTool<Schema extends zod.ZodRawShape>(
  definition: (args: ParsedArguments) => PageToolDefinition<Schema>,
): (args: ParsedArguments) => DefinedPageTool<Schema> {
  return (args: ParsedArguments): DefinedPageTool<Schema> => {
    const tool = definition(args);
    return {
      ...tool,
      schema: {
        ...(args.pageIdRouting && !args.slim ? pageIdSchema : {}),
        ...tool.schema,
      },
      pageScoped: true,
    };
  };
}

export const CLOSE_PAGE_ERROR =
  'The last open page cannot be closed. It is fine to keep it open.';

export const pageIdSchema = {
  pageId: zod.number().describe('Targets a specific page by ID.'),
};

export const timeoutSchema = {
  timeout: zod
    .number()
    .int()
    .transform(value => {
      return value <= 0 ? undefined : value;
    })
    .optional()
    .describe(
      `Maximum wait time in milliseconds. If set to 0, the default timeout will be used.`,
    ),
};

export function viewportTransform(arg: string | undefined):
  | {
      width: number;
      height: number;
      deviceScaleFactor?: number;
      isMobile?: boolean;
      isLandscape?: boolean;
      hasTouch?: boolean;
    }
  | undefined {
  if (!arg) {
    return undefined;
  }
  const [dimensions, ...tags] = arg.split(',');
  const isMobile = tags.includes('mobile');
  const hasTouch = tags.includes('touch');
  const isLandscape = tags.includes('landscape');
  const [width, height, dpr] = dimensions.split('x').map(Number) as [
    number,
    number,
    number | undefined,
  ];
  if (!Number.isFinite(width) || width <= 0) {
    throw new Error(
      `Invalid viewport width "${width}". Expected format '<width>x<height>x<devicePixelRatio>[,mobile][,touch][,landscape]' with a positive width.`,
    );
  }
  if (!Number.isFinite(height) || height <= 0) {
    throw new Error(
      `Invalid viewport height "${height}". Expected format '<width>x<height>x<devicePixelRatio>[,mobile][,touch][,landscape]' with a positive height.`,
    );
  }
  if (dpr !== undefined && (!Number.isFinite(dpr) || dpr <= 0)) {
    throw new Error(
      `Invalid devicePixelRatio "${dpr}". Expected a positive number.`,
    );
  }
  return {
    width,
    height,
    deviceScaleFactor: dpr,
    isMobile: isMobile,
    isLandscape: isLandscape,
    hasTouch: hasTouch,
  };
}

export function geolocationTransform(arg: string | undefined) {
  if (!arg) {
    return undefined;
  }
  const [latitude, longitude] = arg.split(',').map(Number) as [number, number];
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    throw new Error(
      `Invalid latitude "${latitude}". Latitude must be a number between -90 and 90.`,
    );
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    throw new Error(
      `Invalid longitude "${longitude}". Longitude must be a number between -180 and 180.`,
    );
  }
  return {
    latitude,
    longitude,
  };
}
