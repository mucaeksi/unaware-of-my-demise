/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import assert from 'node:assert';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {afterEach, describe, it} from 'node:test';
import {pathToFileURL} from 'node:url';

import {Locator} from 'puppeteer';
import sinon from 'sinon';

import {NetworkFormatter} from '../src/formatters/NetworkFormatter.js';
import {McpContext} from '../src/McpContext.js';
import {McpPage} from '../src/McpPage.js';
import {TextSnapshot} from '../src/TextSnapshot.js';
import {type HTTPResponse} from '../src/third_party/index.js';
import type {TraceResult} from '../src/processors/PerformanceTrace.js';
import {resolveCanonicalPath} from '../src/utils/files.js';

import {serverHooks} from './server.js';
import {
  assertNoServiceWorkerReported,
  getMockRequest,
  html,
  withBrowser,
  withMcpContext,
  stabilizeStructuredContent,
} from './utils.js';

const EXTENSION_WITH_SW_PATH = path.join(
  import.meta.dirname,
  '../../tests/tools/fixtures/extension-sw',
);
const EXTENSION_CONTENT_SCRIPT_PATH = path.join(
  import.meta.dirname,
  '../../tests/tools/fixtures/extension-content-script',
);

describe('McpContext', () => {
  afterEach(() => {
    sinon.restore();
  });

  it('list pages', async () => {
    await withMcpContext(async (_response, context) => {
      const page = context.getSelectedMcpPage();
      await page.pptrPage.setContent(
        html`<button>Click me</button>
          <input
            type="text"
            value="Input"
          />`,
      );
      page.textSnapshot = await TextSnapshot.create(page);
      assert.ok(await page.getElementByUid('1_1'));
      page.textSnapshot = await TextSnapshot.create(page);
      await page.getElementByUid('1_1');
    });
  });

  it('can store and retrieve the latest performance trace', async () => {
    await withMcpContext(async (_response, context) => {
      const fakeTrace1 = {} as unknown as TraceResult;
      const fakeTrace2 = {} as unknown as TraceResult;
      context.storeTraceRecording(fakeTrace1);
      context.storeTraceRecording(fakeTrace2);
      assert.deepEqual(context.recordedTraces(), [fakeTrace2]);
    });
  });

  it('should update default timeout when cpu throttling changes', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      const timeoutBefore = page.pptrPage.getDefaultTimeout();
      await context.getSelectedMcpPage().emulate({cpuThrottlingRate: 2});
      const timeoutAfter = page.pptrPage.getDefaultTimeout();
      assert(timeoutBefore < timeoutAfter, 'Timeout was less then expected');
    });
  });

  it('should update default timeout when network conditions changes', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      const timeoutBefore = page.pptrPage.getDefaultNavigationTimeout();
      await context
        .getSelectedMcpPage()
        .emulate({networkConditions: 'Slow 3G'});
      const timeoutAfter = page.pptrPage.getDefaultNavigationTimeout();
      assert(timeoutBefore < timeoutAfter, 'Timeout was less then expected');
    });
  });

  it('should call waitForEventsAfterAction with correct multipliers', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();

      await context.getSelectedMcpPage().emulate({
        cpuThrottlingRate: 2,
        networkConditions: 'Slow 3G',
      });
      const stub = sinon.spy(page, 'createWaitForHelper');

      await page.waitForEventsAfterAction(async () => {
        // trigger the waiting only
      });

      sinon.assert.calledWithExactly(stub, 2, 10);
    });
  });

  it('should should detect open DevTools pages', async () => {
    await withMcpContext(
      async (_response, context) => {
        const page = await context.newPage();
        await context.createPagesSnapshot();
        assert.ok(await page.getDevToolsPage());

        // A devtools page is tracked but excluded from the listing, so its id
        // must not resolve through `getPageById()` (which backs `select_page`
        // and every other pageId tool). A second snapshot guarantees the
        // devtools page is enrolled.
        await context.createPagesSnapshot();
        const listed = context.getPages();
        assert.ok(
          listed.every(
            mcpPage => !mcpPage.pptrPage.url().startsWith('devtools://'),
          ),
          'listing should exclude devtools pages',
        );
        const listedIds = new Set(listed.map(mcpPage => mcpPage.id));
        for (let id = 1; id < 30; id++) {
          if (listedIds.has(id)) {
            continue;
          }
          assert.throws(() => context.getPageById(id), /No page found/);
        }
      },
      {
        autoOpenDevTools: true,
      },
    );
  });

  it('drops pages reaching internal chrome or chrome-untrusted schemes by any route', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      const pageId = page.id;
      assert.strictEqual(context.getPageById(pageId), page);

      const urlStub = sinon
        .stub(page.pptrPage, 'url')
        .returns('chrome://settings');
      try {
        await context.createPagesSnapshot();
        const listed = context.getPages();
        assert.ok(
          !listed.some(p => p.id === pageId),
          'page reaching chrome://settings should be dropped from listing',
        );
        assert.throws(() => context.getPageById(pageId), /No page found/);
      } finally {
        urlStub.restore();
      }
    });
  });

  it('drops pages with chrome-extension schemes unless categoryExtensions is enabled', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      const pageId = page.id;

      const urlStub = sinon
        .stub(page.pptrPage, 'url')
        .returns('chrome-extension://some-ext-id/popup.html');
      try {
        await context.createPagesSnapshot();
        const listed = context.getPages();
        assert.ok(
          !listed.some(p => p.id === pageId),
          'extension page should be dropped from listing when categoryExtensions is disabled',
        );
        assert.throws(() => context.getPageById(pageId), /No page found/);
      } finally {
        urlStub.restore();
      }
    });
  });

  it('keeps pages with chrome://newtab/ and chrome://inspect', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      const pageId = page.id;

      const newtabStub = sinon
        .stub(page.pptrPage, 'url')
        .returns('chrome://newtab/');
      try {
        await context.createPagesSnapshot();
        const listed = context.getPages();
        assert.ok(
          listed.some(p => p.id === pageId),
          'chrome://newtab/ should be kept in listing',
        );
        assert.strictEqual(context.getPageById(pageId), page);
      } finally {
        newtabStub.restore();
      }

      const inspectStub = sinon
        .stub(page.pptrPage, 'url')
        .returns('chrome://inspect/#devices');
      try {
        await context.createPagesSnapshot();
        const listed = context.getPages();
        assert.ok(
          listed.some(p => p.id === pageId),
          'chrome://inspect should be kept in listing',
        );
        assert.strictEqual(context.getPageById(pageId), page);
      } finally {
        inspectStub.restore();
      }
    });
  });

  it('resolves uid from a non-selected page snapshot', async () => {
    await withMcpContext(async (_response, context) => {
      // Page 1: set content and snapshot
      const page1 = context.getSelectedMcpPage();
      await page1.pptrPage.setContent(html`<button>Page1 Button</button>`);
      page1.textSnapshot = await TextSnapshot.create(page1, {
        verbose: false,
      });

      // Capture a uid from page1's snapshot (snapshotId=1, button is node 1)
      const page1Uid = '1_1';
      const page1Node = page1.getAXNodeByUid(page1Uid);
      assert.ok(page1Node, 'uid should resolve from page1 snapshot');

      // Page 2: new page, set content, snapshot
      const page2 = await context.newPage();
      context.selectPage(page2);
      await page2.pptrPage.setContent(html`<button>Page2 Button</button>`);
      page2.textSnapshot = await TextSnapshot.create(page2, {
        verbose: false,
      });

      // Page 2 is now selected. Page 1's uid should still resolve.
      const node = page1.getAXNodeByUid(page1Uid);
      assert.ok(node, 'page1 uid should still resolve after page2 snapshot');
      assert.strictEqual(node?.name, 'Page1 Button');

      // The element should also be retrievable when the target page is provided.
      const element = await page1.getElementByUid(page1Uid);
      assert.ok(element, 'should get element handle from page1 snapshot uid');
    });
  });

  it('reports the fallback when the selected page is closed', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      assert.ok(context.isPageSelected(page));

      await page.pptrPage.close();
      await context.createPagesSnapshot();

      const [firstPage] = context.getPages();
      assert.ok(firstPage);
      assert.ok(context.isPageSelected(firstPage));

      const fallback = context.getSelectedPageFallback();
      assert.ok(fallback, 'fallback should be reported');
      assert.strictEqual(fallback.wasClosed, true);
    });
  });

  it('clears the fallback on the next snapshot with a valid selection', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      await page.pptrPage.close();
      await context.createPagesSnapshot();
      assert.ok(context.getSelectedPageFallback());

      // A later snapshot keeps a valid selection (e.g. the one taken before the
      // next response, or after an explicit select), so the note is not repeated.
      await context.createPagesSnapshot();
      assert.strictEqual(context.getSelectedPageFallback(), undefined);
    });
  });

  it('does not report a fallback for a regular selection', async () => {
    await withMcpContext(async (_response, context) => {
      await context.newPage();
      await context.createPagesSnapshot();
      assert.strictEqual(context.getSelectedPageFallback(), undefined);
    });
  });

  it('keeps a still-open selected page that is missing from the list', async () => {
    await withMcpContext(async (_response, context) => {
      const page = await context.newPage();
      assert.ok(context.isPageSelected(page));

      // A live page that is temporarily missing from the pages list must keep
      // its selection — only a genuinely closed page is replaced.
      const pages = await context.browser.pages();
      const stub = sinon
        .stub(context.browser, 'pages')
        .resolves(pages.filter(otherPage => otherPage !== page.pptrPage));
      try {
        await context.createPagesSnapshot();
      } finally {
        stub.restore();
      }

      assert.ok(
        context.isPageSelected(page),
        'a still-open page should keep its selection',
      );
      assert.strictEqual(context.getSelectedPageFallback(), undefined);
    });
  });

  it('continues page ids across contexts so stale ids do not resolve', async () => {
    await withBrowser(async browser => {
      const options = {
        experimentalDevToolsDebugging: false,
        performanceCrux: false,
      };
      const first = await McpContext.from(browser, undefined, options, Locator);
      const idBeforeReconnect = (await first.newPage()).id;
      first.dispose();

      // A new context (as created after a browser reconnect) continues the
      // shared id counter, so an id handed out before no longer resolves and
      // the next page keeps counting up rather than colliding with it.
      const second = await McpContext.from(
        browser,
        undefined,
        options,
        Locator,
      );
      try {
        assert.throws(
          () => second.getPageById(idBeforeReconnect),
          /No page found/,
        );
        assert.ok(
          (await second.newPage()).id > idBeforeReconnect,
          'ids continue past the pre-reconnect ids',
        );
      } finally {
        second.dispose();
      }
    });
  });

  it('reports the reconnect notice once', async () => {
    await withBrowser(async browser => {
      const context = await McpContext.from(
        browser,
        undefined,
        {
          experimentalDevToolsDebugging: false,
          performanceCrux: false,
          reconnected: true,
        },
        Locator,
      );
      try {
        assert.ok(context.consumeReconnectNotice(), 'notice available once');
        assert.ok(!context.consumeReconnectNotice(), 'notice does not repeat');
      } finally {
        context.dispose();
      }
    });
  });

  it('disposes loaded heap snapshots on teardown', async () => {
    await withMcpContext(async (_response, context) => {
      const filePath = path.join(
        process.cwd(),
        'tests/fixtures/example.heapsnapshot',
      );
      await context.getHeapSnapshotStats(filePath);
      assert.ok(context.hasHeapSnapshots(), 'snapshot loaded before teardown');

      context.dispose();

      assert.ok(
        !context.hasHeapSnapshots(),
        'heap snapshots freed on teardown',
      );
    });
  });

  it('should include network requests in structured content', async t => {
    await withMcpContext(async (response, context) => {
      const mockRequest = getMockRequest({
        url: 'http://example.com/api',
        stableId: 123,
      });

      sinon
        .stub(context.getSelectedMcpPage(), 'getNetworkRequests')
        .returns([mockRequest]);

      response.setIncludeNetworkRequests(true);
      const result = await response.handle(context);
      t.assert.snapshot(stabilizeStructuredContent(result.structuredContent));
    });
  });

  it('should include detailed network request in structured content', async t => {
    await withMcpContext(async (response, context) => {
      const mockRequest = getMockRequest({
        url: 'http://example.com/detail',
        stableId: 456,
      });

      sinon
        .stub(context.getSelectedMcpPage(), 'getNetworkRequestById')
        .returns(mockRequest);

      response.attachNetworkRequest(456);
      const result = await response.handle(context);

      t.assert.snapshot(stabilizeStructuredContent(result.structuredContent));
    });
  });

  it('should include file paths in structured content when saving to file', async t => {
    await withMcpContext(async (response, context) => {
      const mockRequest = getMockRequest({
        url: 'http://example.com/file-save',
        stableId: 789,
        hasPostData: true,
        postData: 'some detailed data',
        response: {
          status: () => 200,
          headers: () => ({'content-type': 'text/plain'}),
          buffer: async () => Buffer.from('some response data'),
        } as unknown as HTTPResponse,
      });

      sinon
        .stub(context.getSelectedMcpPage(), 'getNetworkRequestById')
        .returns(mockRequest);

      // Use os.tmpdir() so validatePath passes on all platforms (macOS tmpdir
      // is /var/folders/..., not /tmp, so hardcoded /tmp paths are rejected).
      const reqFilePath = path.join(os.tmpdir(), 'req.txt');
      const resFilePath = path.join(os.tmpdir(), 'res.txt');

      // We stub NetworkFormatter.from to avoid actual file system writes and verify arguments
      const fromStub = sinon
        .stub(NetworkFormatter, 'from')
        .callsFake(async (_req, opts) => {
          // Verify we received the platform-correct file paths
          assert.strictEqual(opts?.requestFilePath, reqFilePath);
          assert.strictEqual(opts?.responseFilePath, resFilePath);
          // Return fixed strings in toJSONDetailed so the snapshot is stable
          // across platforms (os.tmpdir() differs on macOS vs Linux/Windows).
          return {
            toStringDetailed: () => 'Detailed string',
            toJSONDetailed: () => ({
              requestBody: '/tmp/req.txt',
              responseBody: '/tmp/res.txt',
            }),
          } as unknown as NetworkFormatter;
        });

      response.attachNetworkRequest(789, {
        requestFilePath: reqFilePath,
        responseFilePath: resFilePath,
      });
      const result = await response.handle(context);

      t.assert.snapshot(stabilizeStructuredContent(result.structuredContent));

      fromStub.restore();
    });
  });

  it('can store and retrieve roots', async () => {
    await withMcpContext(async (_response, context) => {
      const roots = [{uri: 'file:///test', name: 'test'}];
      context.setRoots(roots);
      const actualRoots = context.roots();
      assert.ok(
        actualRoots?.some(r => r.name === 'test'),
        'Should contain the set root',
      );
      assert.ok(
        actualRoots?.some(r => r.name === 'temp'),
        'Should contain the temp root',
      );
    });
  });

  it('validatePath allows paths within roots', async () => {
    await withMcpContext(async (_response, context) => {
      const workspacePath = path.resolve(os.homedir(), 'workspace-test');
      await fs.mkdir(workspacePath, {recursive: true});
      try {
        const roots = [
          {uri: pathToFileURL(workspacePath).href, name: 'workspace'},
        ];
        context.setRoots(roots);
        // Valid path within root
        const targetPath = path.join(workspacePath, 'test.txt');
        const resolved = await context.validatePath(targetPath);
        assert.strictEqual(resolved, await resolveCanonicalPath(targetPath));
        const resolvedWorkspace = await context.validatePath(workspacePath);
        assert.strictEqual(
          resolvedWorkspace,
          await resolveCanonicalPath(workspacePath),
        );

        // Invalid path outside root and outside temp dir
        const outsidePath = path.resolve(os.homedir(), 'outside-test.txt');
        await assert.rejects(
          context.validatePath(outsidePath),
          /Access denied/,
        );
      } finally {
        await fs.rm(workspacePath, {recursive: true, force: true});
      }
    });
  });

  it('validatePath allows non-existent nested paths within roots', async () => {
    await withMcpContext(async (_response, context) => {
      const workspacePath = path.resolve(os.homedir(), 'workspace-test-nested');
      await fs.mkdir(workspacePath, {recursive: true});
      try {
        const roots = [
          {uri: pathToFileURL(workspacePath).href, name: 'workspace'},
        ];
        context.setRoots(roots);
        // Valid path within root with non-existent intermediate directories
        const targetPath = path.join(workspacePath, 'dir1', 'dir2', 'test.txt');
        const resolved = await context.validatePath(targetPath);
        assert.strictEqual(resolved, await resolveCanonicalPath(targetPath));
      } finally {
        await fs.rm(workspacePath, {recursive: true, force: true});
      }
    });
  });

  it('validatePath allows all paths if roots are undefined and allowUnrestrictedPaths is set', async () => {
    await withMcpContext(
      async (_response, context) => {
        context.setRoots(undefined);
        const targetPath = path.resolve(os.homedir(), 'anywhere.txt');
        const resolved = await context.validatePath(targetPath);
        assert.strictEqual(resolved, await resolveCanonicalPath(targetPath));
      },
      {allowUnrestrictedPaths: true},
    );
  });

  it('validatePath returns undefined if filePath is undefined', async () => {
    await withMcpContext(async (_response, context) => {
      const resolved = await context.validatePath(undefined);
      assert.strictEqual(resolved, undefined);
    });
  });

  it('validatePath returns resolved absolute path for relative paths', async () => {
    await withMcpContext(async (_response, context) => {
      const tmpDir = os.tmpdir();
      const relativeTmpPath = path.relative(
        process.cwd(),
        path.join(tmpDir, 'test.txt'),
      );
      const resolved = await context.validatePath(relativeTmpPath);
      assert.strictEqual(resolved, await resolveCanonicalPath(relativeTmpPath));
    });
  });

  it('validatePath denies paths outside tmpdir if roots are undefined and allowUnrestrictedPaths is not set', async () => {
    await withMcpContext(async (_response, context) => {
      // setRoots() never called — simulates a client that skips roots capability.
      const outsidePath = path.resolve(os.homedir(), 'anywhere.txt');
      await assert.rejects(context.validatePath(outsidePath), /Access denied/);
      // Temp dir must still be reachable.
      const tmpPath = path.join(os.tmpdir(), 'test.txt');
      const resolved = await context.validatePath(tmpPath);
      assert.strictEqual(resolved, await resolveCanonicalPath(tmpPath));
    });
  });

  it('validatePath denies paths outside os.tmpdir() if roots list is empty', async () => {
    await withMcpContext(async (_response, context) => {
      context.setRoots([]);
      // Should allow temp dir
      const tmpPath = path.join(os.tmpdir(), 'test.txt');
      const resolved = await context.validatePath(tmpPath);
      assert.strictEqual(resolved, await resolveCanonicalPath(tmpPath));

      // Should deny outside temp dir
      await assert.rejects(
        context.validatePath(path.resolve(os.homedir(), 'anywhere.txt')),
        /Access denied/,
      );
    });
  });

  describe('symlink security checks', () => {
    // Symlinks are not followed on Windows by default.
    if (os.platform() === 'win32') {
      return;
    }

    it('validatePath resolves symlinks and returns the canonical path', async () => {
      await withMcpContext(async (_response, context) => {
        const tmpDir = await fs.mkdtemp(
          path.join(os.tmpdir(), 'validate-symlink-test-'),
        );
        try {
          const targetDir = path.join(tmpDir, 'target');
          await fs.mkdir(targetDir);
          const targetFile = path.join(targetDir, 'file.txt');
          await fs.writeFile(targetFile, 'hello');

          const symlinkDir = path.join(tmpDir, 'symlink_dir');
          await fs.symlink(targetDir, symlinkDir, 'dir');

          const canonicalTarget = await fs.realpath(targetDir);
          context.setRoots([
            {uri: pathToFileURL(canonicalTarget).href, name: 'target'},
          ]);

          const filePathWithSymlink = path.join(symlinkDir, 'file.txt');
          const resolved = await context.validatePath(filePathWithSymlink);
          assert.strictEqual(resolved, path.join(canonicalTarget, 'file.txt'));
        } finally {
          await fs.rm(tmpDir, {recursive: true, force: true});
        }
      });
    });

    it('saveFile allows writing to a symlinked file if it resolves to an allowed path', async () => {
      await withMcpContext(async (_response, context) => {
        const tmpDir = await fs.mkdtemp(
          path.join(os.tmpdir(), 'mcp-symlink-test-'),
        );
        try {
          context.setRoots([{uri: pathToFileURL(tmpDir).href, name: 'temp'}]);

          const targetPath = path.join(tmpDir, 'target.txt');
          await fs.writeFile(targetPath, 'original content', 'utf-8');

          const symlinkPath = path.join(tmpDir, 'symlink.txt');
          await fs.symlink(targetPath, symlinkPath);

          const data = new TextEncoder().encode('content');
          await context.saveFile(data, symlinkPath, '.txt');
          await context.saveFile(data, targetPath, '.txt');

          const content = await fs.readFile(targetPath, 'utf-8');
          assert.strictEqual(content, 'content');
        } finally {
          await fs.rm(tmpDir, {recursive: true, force: true});
        }
      });
    });

    it('saveFile refuses to write through a dangling symlink to a non-existent file', async () => {
      await withMcpContext(async (_response, context) => {
        const tmpDir = await fs.mkdtemp(
          path.join(os.tmpdir(), 'mcp-symlink-test-'),
        );
        const outsideDir = await fs.mkdtemp(
          path.join(os.tmpdir(), 'mcp-outside-test-'),
        );
        try {
          context.setRoots([{uri: pathToFileURL(tmpDir).href, name: 'temp'}]);

          const outsideTarget = path.join(outsideDir, 'target.txt');
          const symlinkPath = path.join(tmpDir, 'symlink.txt');
          await fs.symlink(outsideTarget, symlinkPath);

          const data = new TextEncoder().encode('malicious content');
          await assert.rejects(
            context.saveFile(data, symlinkPath, '.txt'),
            /Could not write/,
          );

          await assert.rejects(fs.stat(outsideTarget));
        } finally {
          await fs.rm(tmpDir, {recursive: true, force: true});
          await fs.rm(outsideDir, {recursive: true, force: true});
        }
      });
    });

    it('saveFile allows writing to a file within an allowed symlinked directory', async () => {
      await withMcpContext(async (_response, context) => {
        const tmpDir = await fs.mkdtemp(
          path.join(os.tmpdir(), 'mcp-symlink-test-'),
        );
        try {
          context.setRoots([{uri: pathToFileURL(tmpDir).href, name: 'temp'}]);

          const realDir = path.join(tmpDir, 'real_dir');
          await fs.mkdir(realDir, {recursive: true});

          const symlinkedDir = path.join(tmpDir, 'symlinked_dir');
          await fs.symlink(realDir, symlinkedDir);

          const targetFilePath = path.join(symlinkedDir, 'test.txt');
          const data = new TextEncoder().encode('allowed content');

          const result = await context.saveFile(data, targetFilePath, '.txt');
          assert.strictEqual(
            result.filename,
            await resolveCanonicalPath(targetFilePath),
          );
          const content = await fs.readFile(
            path.join(realDir, 'test.txt'),
            'utf-8',
          );
          assert.strictEqual(content, 'allowed content');
        } finally {
          await fs.rm(tmpDir, {recursive: true, force: true});
        }
      });
    });
  });

  describe('loadResource', () => {
    describe('file protocol', () => {
      it('calls validatePath', async () => {
        await withMcpContext(async (_response, context) => {
          const validatePathSpy = sinon.spy(context, 'validatePath');
          const testFilePath = path.join(os.tmpdir(), 'load-resource-test.txt');
          await fs.writeFile(testFilePath, 'test content');
          try {
            const url = pathToFileURL(testFilePath).href;
            const content = await context.loadResource(url);
            assert.strictEqual(content, 'test content');
            sinon.assert.calledWith(validatePathSpy, testFilePath);
          } finally {
            await fs.rm(testFilePath, {force: true});
          }
        });
      });

      it('is not blocked by allowlist', async () => {
        const testFilePath = path.join(
          os.tmpdir(),
          'load-resource-test-allow.txt',
        );
        await fs.writeFile(testFilePath, 'test content');
        try {
          await withMcpContext(
            async (_response, context) => {
              const url = pathToFileURL(testFilePath).href;
              const content = await context.loadResource(url);
              assert.strictEqual(content, 'test content');
            },
            {
              allowedUrlPattern: ['https://example.com/allowed*'],
            },
          );
        } finally {
          await fs.rm(testFilePath, {force: true});
        }
      });
    });

    describe('https protocol', () => {
      it('respects blocklist by throwing if blocked', async () => {
        await withMcpContext(
          async (_response, context) => {
            await assert.rejects(() =>
              context.loadResource('https://example.com/blocked'),
            );
          },
          {
            blockedUrlPattern: ['https://example.com/blocked*'],
          },
        );
      });

      it('respects blocklist by not throwing if not blocked', async () => {
        await withMcpContext(
          async (_response, context) => {
            sinon.stub(globalThis, 'fetch').resolves({
              ok: true,
              text: async () => 'mock data',
            } as Response);

            const content = await context.loadResource(
              'https://example.com/allowed',
            );
            assert.strictEqual(content, 'mock data');
          },
          {
            blockedUrlPattern: ['https://example.com/blocked*'],
          },
        );
      });

      it('respects allowlist by throwing if not allowed', async () => {
        await withMcpContext(
          async (_response, context) => {
            await assert.rejects(() =>
              context.loadResource('https://example.com/blocked'),
            );
          },
          {
            allowedUrlPattern: ['https://example.com/allowed*'],
          },
        );
      });

      it('respects allowlist by not throwing if allowed', async () => {
        await withMcpContext(
          async (_response, context) => {
            sinon.stub(globalThis, 'fetch').resolves({
              ok: true,
              text: async () => 'mock data',
            } as Response);

            const content = await context.loadResource(
              'https://example.com/allowed',
            );
            assert.strictEqual(content, 'mock data');
          },
          {
            allowedUrlPattern: ['https://example.com/allowed*'],
          },
        );
      });
    });

    describe('getDevToolsData', () => {
      it('returns devtools data from passed page', async () => {
        await withMcpContext(async (_response, context) => {
          const mockPage = sinon.createStubInstance(McpPage);
          mockPage.getDevToolsData.resolves({cdpBackendNodeId: 42});
          const result = await context.getDevToolsData(mockPage);
          assert.deepStrictEqual(result, {cdpBackendNodeId: 42});
        });
      });

      it('returns undefined when getDevToolsData times out', async () => {
        await withMcpContext(async (_response, context) => {
          const mockPage = sinon.createStubInstance(McpPage);
          mockPage.getDevToolsData.returns(
            new Promise(resolve => {
              setTimeout(() => resolve({cdpBackendNodeId: 100}), 600);
            }),
          );
          const result = await context.getDevToolsData(mockPage);
          assert.strictEqual(result, undefined);
        });
      });

      it('returns empty object from selected page when devtools is closed', async () => {
        await withMcpContext(async (_response, context) => {
          const result = await context.getDevToolsData();
          assert.deepStrictEqual(result, {});
        });
      });
    });

    describe('getSelectedMcpPageUrl', () => {
      it('returns url from passed page when open', async () => {
        await withMcpContext(async (_response, context) => {
          const page = await context.newPage();
          const result = context.getSelectedMcpPageUrl(page);
          assert.strictEqual(result, page.pptrPage.url());
        });
      });

      it('returns undefined from passed page when closed', async () => {
        await withMcpContext(async (_response, context) => {
          const page = await context.newPage();
          await page.pptrPage.close();
          const result = context.getSelectedMcpPageUrl(page);
          assert.strictEqual(result, undefined);
        });
      });

      it('returns url from selected page when no page passed', async () => {
        await withMcpContext(async (_response, context) => {
          const page = context.getSelectedMcpPage();
          const result = context.getSelectedMcpPageUrl();
          assert.strictEqual(result, page.pptrPage.url());
        });
      });

      it('returns undefined when getSelectedMcpPage throws', async () => {
        await withMcpContext(async (_response, context) => {
          sinon
            .stub(context, 'getSelectedMcpPage')
            .throws(new Error('No page selected'));
          const result = context.getSelectedMcpPageUrl();
          assert.strictEqual(result, undefined);
        });
      });

      it('returns undefined when selected page is closed and getSelectedMcpPage throws', async () => {
        await withMcpContext(async (_response, context) => {
          const page = context.getSelectedMcpPage();
          await page.pptrPage.close();
          assert.throws(() => context.getSelectedMcpPage());
          const result = context.getSelectedMcpPageUrl();
          assert.strictEqual(result, undefined);
        });
      });
    });
  });

  describe('extensions', () => {
    const server = serverHooks();

    it('manages extension lifecycle (install, list, get, reload, triggerAction, and uninstall)', async () => {
      await withMcpContext(
        async (_response, context) => {
          const extensionId = await context.installExtension(
            EXTENSION_WITH_SW_PATH,
          );

          let extensions = await context.listExtensions();
          assert.ok(
            extensions.has(extensionId),
            `Extension with ID "${extensionId}" should be installed`,
          );

          const extension = await context.getExtension(extensionId);
          assert.ok(extension, 'Extension should be returned');
          assert.strictEqual(extension.id, extensionId);
          assert.strictEqual(extension.path, EXTENSION_WITH_SW_PATH);

          await context.installExtension(extension.path);
          extensions = await context.listExtensions();
          assert.ok(
            extensions.has(extensionId),
            'Extension should still be installed after reload',
          );

          const targetsBefore = context.browser.targets();
          const pageTargetBefore = targetsBefore.find(
            t => t.type() === 'page' && t.url().includes(extensionId),
          );
          assert.ok(!pageTargetBefore, 'Page should not exist before action');

          await context.triggerExtensionAction(extensionId);

          const pageTargetAfter = await context.browser.waitForTarget(
            t => t.type() === 'page' && t.url().includes(extensionId),
          );
          assert.ok(pageTargetAfter, 'Page should exist after action');

          await context.uninstallExtension(extensionId);
          extensions = await context.listExtensions();
          assert.ok(
            !extensions.has(extensionId),
            `Extension with ID "${extensionId}" should NOT be installed`,
          );

          const targets = context.browser.targets();
          assertNoServiceWorkerReported(targets, extensionId);
        },
        {},
        {
          categoryExtensions: true,
        },
      );
    });

    it('verifies that content script console logs are received', async () => {
      await withMcpContext(
        async (_response, context) => {
          server.addHtmlRoute(
            '/test-content-script',
            html`<h1>Test Content Script</h1>`,
          );
          const url = server.getRoute('/test-content-script');

          const extensionId = await context.installExtension(
            EXTENSION_CONTENT_SCRIPT_PATH,
          );

          const mcpPage = context.getSelectedMcpPage();
          const page = mcpPage.pptrPage;

          await page.goto(url);

          const messages = mcpPage.getConsoleData(true);
          const hasContentScriptLog = messages.some(
            message =>
              'text' in message &&
              typeof message.text === 'function' &&
              message.text().includes('from content script!'),
          );
          assert.ok(
            hasContentScriptLog,
            'Console output should contain message from content script.',
          );

          await context.uninstallExtension(extensionId);
        },
        {},
        {
          categoryExtensions: true,
        },
      );
    });
  });
});
