/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import assert from 'node:assert';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {describe, it, afterEach, beforeEach} from 'node:test';

import {
  assertDaemonIsNotRunning,
  assertDaemonIsRunning,
  runCli,
} from '../utils.js';

describe('chrome-devtools', () => {
  let sessionId: string;

  beforeEach(async () => {
    sessionId = crypto.randomUUID();
    await runCli(['stop'], sessionId);
    await assertDaemonIsNotRunning(sessionId);
  });

  afterEach(async () => {
    await runCli(['stop'], sessionId);
    await assertDaemonIsNotRunning(sessionId);
  });

  it('can start and stop the daemon', async () => {
    await assertDaemonIsNotRunning(sessionId);

    const startResult = await runCli(['start'], sessionId);
    assert.strictEqual(
      startResult.status,
      0,
      `start command failed: ${startResult.stderr}`,
    );

    await assertDaemonIsRunning(sessionId);

    const stopResult = await runCli(['stop'], sessionId);
    assert.strictEqual(
      stopResult.status,
      0,
      `stop command failed: ${stopResult.stderr}`,
    );

    await assertDaemonIsNotRunning(sessionId);
  });

  it('can start the daemon with userDataDir', async () => {
    const userDataDir = path.join(
      os.tmpdir(),
      `chrome-devtools-test-${crypto.randomUUID()}`,
    );
    fs.mkdirSync(userDataDir, {recursive: true});

    const startResult = await runCli(
      ['start', '--userDataDir', userDataDir],
      sessionId,
    );
    assert.strictEqual(
      startResult.status,
      0,
      `start command failed: ${startResult.stderr}`,
    );
    assert.ok(
      !startResult.stderr.includes(
        'Arguments userDataDir and isolated are mutually exclusive',
      ),
      `unexpected conflict error: ${startResult.stderr}`,
    );

    await assertDaemonIsRunning(sessionId);
  });

  it('forwards an explicit headless=false option', async () => {
    const startResult = await runCli(['start', '--headless=false'], sessionId);
    assert.strictEqual(
      startResult.status,
      0,
      `start command failed: ${startResult.stderr}`,
    );

    const statusResult = await runCli(['status'], sessionId);
    assert.strictEqual(statusResult.status, 0);
    assert.ok(
      statusResult.stdout.includes('--no-headless'),
      `headless=false was not forwarded: ${statusResult.stdout}`,
    );
  });

  it('can start the daemon with a workspace', async () => {
    const workspace = fs.mkdtempSync(
      path.join(os.tmpdir(), 'chrome-devtools-workspace-'),
    );

    try {
      const startResult = await runCli(
        ['start', '--workspace', workspace],
        sessionId,
      );
      assert.strictEqual(
        startResult.status,
        0,
        `start command failed: ${startResult.stderr}`,
      );

      const statusResult = await runCli(['status'], sessionId);
      assert.strictEqual(statusResult.status, 0);
      assert.ok(
        statusResult.stdout.includes('--filesystem-root=') &&
          statusResult.stdout.includes(path.basename(workspace)),
        `workspace was not forwarded: ${statusResult.stdout}`,
      );
    } finally {
      fs.rmSync(workspace, {recursive: true, force: true});
    }
  });
});
