import json
from pathlib import Path
import networkx as nx
import pytest
from networkx.readwrite import json_graph
from graphify.build import build_from_json, build, build_merge, edge_data, edge_datas, dedupe_edges, dedupe_nodes

FIXTURES = Path(__file__).parent / "fixtures"


def test_dedupe_edges_collapses_exact_parallels():
    # #1317: --no-cluster / incremental update concatenate edge lists raw.
    edges = [
        {"source": "a", "target": "b", "relation": "calls", "source_location": "L1"},
        {"source": "a", "target": "b", "relation": "calls", "source_location": "L9"},  # dup
        {"source": "a", "target": "b", "relation": "imports"},  # different relation: kept
        {"source": "b", "target": "c", "relation": "calls"},
    ]
    out = dedupe_edges(edges)
    keys = [(e["source"], e["target"], e["relation"]) for e in out]
    assert keys == [("a", "b", "calls"), ("a", "b", "imports"), ("b", "c", "calls")]
    # first occurrence wins (keeps L1, not L9)
    assert out[0]["source_location"] == "L1"


def test_dedupe_edges_is_idempotent():
    edges = [
        {"source": "a", "target": "b", "relation": "calls"},
        {"source": "a", "target": "b", "relation": "calls"},
    ]
    once = dedupe_edges(edges)
    twice = dedupe_edges(once + edges)  # simulate a second `update` re-concatenating
    assert len(once) == 1
    assert len(twice) == 1


def test_dedupe_nodes_collapses_by_id_last_wins():
    # #1327: a shared module anchor is emitted once per importing file; the
    # --no-cluster raw writer must collapse same-id node dicts (#1317).
    nodes = [
        {"id": "foundation", "label": "Foundation", "type": "module", "source_file": "A.swift"},
        {"id": "akit", "label": "AKit", "file_type": "code"},
        {"id": "foundation", "label": "Foundation", "type": "module", "source_file": "B.swift"},
    ]
    out = dedupe_nodes(nodes)
    ids = [n["id"] for n in out]
    assert ids == ["foundation", "akit"]  # first-appearance order
    # last writer wins on attributes
    assert next(n for n in out if n["id"] == "foundation")["source_file"] == "B.swift"

def load_extraction():
    return json.loads((FIXTURES / "extraction.json").read_text())

def test_build_from_json_node_count():
    G = build_from_json(load_extraction())
    assert G.number_of_nodes() == 4

def test_build_from_json_edge_count():
    G = build_from_json(load_extraction())
    assert G.number_of_edges() == 4

def test_null_weight_edge_builds_and_clusters(tmp_path):
    """#1960: an explicit ``"weight": null`` (JSON null -> None) used to survive
    ``.get("weight", 1.0)`` and crash Louvain/Leiden modularity with a TypeError.
    It must now coerce to the 1.0 default, build, and cluster without raising."""
    from graphify.cluster import cluster
    extraction = {
        "nodes": [
            {"id": "a", "label": "A", "file_type": "code", "source_file": "a.py"},
            {"id": "b", "label": "B", "file_type": "code", "source_file": "b.py"},
            {"id": "c", "label": "C", "file_type": "code", "source_file": "c.py"},
        ],
        "edges": [
            {"source": "a", "target": "b", "relation": "references", "weight": None,
             "confidence_score": None},
            {"source": "b", "target": "c", "relation": "references", "weight": 2.5},
        ],
    }
    G = build_from_json(extraction)
    assert G["a"]["b"]["weight"] == 1.0            # null coerced to default
    assert G["a"]["b"]["confidence_score"] == 1.0  # null confidence_score too
    assert G["b"]["c"]["weight"] == 2.5            # a valid weight is preserved
    cluster(G)  # must not raise (Louvain/Leiden modularity)


def test_malformed_weights_normalize():
    """Non-numeric / NaN / inf / negative weights fall back to 1.0 (the backends
    reject them); a missing weight key is left absent (backends default it)."""
    extraction = {
        "nodes": [{"id": f"n{i}", "label": str(i), "file_type": "code",
                   "source_file": f"{i}.py"} for i in range(4)],
        "edges": [
            {"source": "n0", "target": "n1", "relation": "references", "weight": "3.5"},
            {"source": "n1", "target": "n2", "relation": "references", "weight": float("nan")},
            {"source": "n2", "target": "n3", "relation": "references", "weight": -4},
        ],
    }
    G = build_from_json(extraction)
    assert G["n0"]["n1"]["weight"] == 3.5     # numeric string coerces
    assert G["n1"]["n2"]["weight"] == 1.0     # NaN -> default
    assert G["n2"]["n3"]["weight"] == 1.0     # negative -> default


def test_nodes_have_label():
    G = build_from_json(load_extraction())
    assert G.nodes["n_transformer"]["label"] == "Transformer"

def test_edges_have_confidence():
    G = build_from_json(load_extraction())
    data = G.edges["n_attention", "n_concept_attn"]
    assert data["confidence"] == "INFERRED"

def test_ambiguous_edge_preserved():
    G = build_from_json(load_extraction())
    data = G.edges["n_layernorm", "n_concept_attn"]
    assert data["confidence"] == "AMBIGUOUS"

def test_legacy_node_source_canonicalized():
    """Legacy 'source' key on nodes is renamed to 'source_file' before graph build."""
    ext = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source": "a.py"}],
           "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    assert "source_file" in G.nodes["n1"]
    assert G.nodes["n1"]["source_file"] == "a.py"
    assert "source" not in G.nodes["n1"]


def test_legacy_edge_from_to_canonicalized():
    """Legacy 'from'/'to' keys on edges are accepted alongside 'source'/'target'."""
    ext = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"}],
           "edges": [{"from": "n1", "to": "n2", "relation": "calls",
                      "confidence": "EXTRACTED", "source_file": "a.py", "weight": 1.0}],
           "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    assert G.number_of_edges() == 1


def test_legacy_node_name_path_aliases_folded():
    """#2194: nodes carrying `name`/`path` instead of `label`/`source_file` must
    be canonicalized before validation, not enter the graph as label-less
    ghosts. After build the canonicalized dict also passes validation."""
    from graphify.validate import validate_extraction
    ext = {"nodes": [{"id": "n1", "name": "Foo", "path": "a/b.md", "file_type": "concept"}],
           "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    attrs = G.nodes["n1"]
    assert attrs["label"] == "Foo"
    assert attrs["source_file"] == "a/b.md"
    assert "name" not in attrs
    assert "path" not in attrs
    # build_from_json canonicalizes in place; the extraction dict must now be
    # schema-valid (no missing-field errors for the alias node).
    assert not [e for e in validate_extraction(ext) if "missing required field" in e]


def test_legacy_edge_type_confidence_score_aliases_folded():
    """#2194: edges carrying `type`/`confidence_score` instead of
    `relation`/`confidence` fold to canonical fields. Recovery confidence is
    INFERRED (never EXTRACTED — alias recovery is not provenance) and the
    companion confidence_score float is retained, not popped."""
    ext = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"}],
           "edges": [{"source": "n1", "target": "n2", "type": "references",
                      "confidence_score": 0.9, "source_file": "a.py"}],
           "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    data = edge_data(G, "n1", "n2")
    assert data["relation"] == "references"
    assert data["confidence"] == "INFERRED"
    assert data["confidence_score"] == 0.9
    assert "type" not in data


def test_legacy_numeric_confidence_normalized_to_inferred(capsys):
    """Pre-enum graphs stored the LLM pass's float directly in `confidence`
    (1.0/0.95/0.9/0.85). Reloading such a graph must not warn once per edge on
    every load — the number normalizes to INFERRED (numeric confidences only
    ever came from the LLM semantic pass, and LLM-derived edges are INFERRED
    by definition) with the original float preserved in confidence_score."""
    ext = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"},
                     {"id": "n3", "label": "C", "file_type": "code", "source_file": "c.py"}],
           "edges": [{"source": "n1", "target": "n2", "relation": "calls",
                      "confidence": 0.95, "source_file": "a.py"},
                     {"source": "n2", "target": "n3", "relation": "references",
                      "confidence": 1.0, "source_file": "b.py"}],
           "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    err = capsys.readouterr().err
    assert "invalid confidence" not in err
    assert "Extraction warning" not in err
    d12 = edge_data(G, "n1", "n2")
    assert d12["confidence"] == "INFERRED"
    assert d12["confidence_score"] == 0.95
    d23 = edge_data(G, "n2", "n3")
    assert d23["confidence"] == "INFERRED"
    assert d23["confidence_score"] == 1.0


def test_legacy_numeric_confidence_existing_score_wins():
    """A numeric `confidence` next to an explicit `confidence_score` must not
    overwrite the explicit score — the companion field is the authority."""
    ext = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"}],
           "edges": [{"source": "n1", "target": "n2", "relation": "calls",
                      "confidence": 0.9, "confidence_score": 0.4, "source_file": "a.py"}],
           "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    data = edge_data(G, "n1", "n2")
    assert data["confidence"] == "INFERRED"
    assert data["confidence_score"] == 0.4


def test_legacy_numeric_confidence_links_spelling_reload(capsys):
    """The on-disk shape of the defect: a NetworkX-serialized graph.json
    (`links` spelling) from a pre-enum version reloads without a validator
    warning per edge and its edges land INFERRED."""
    raw = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"}],
           "links": [{"source": "n1", "target": "n2", "relation": "calls",
                      "confidence": 0.85, "source_file": "a.py"}]}
    G = build_from_json(raw)
    err = capsys.readouterr().err
    assert "invalid confidence" not in err
    data = edge_data(G, "n1", "n2")
    assert data["confidence"] == "INFERRED"
    assert data["confidence_score"] == 0.85


def test_legacy_numeric_confidence_normalization_is_idempotent(capsys):
    """Healing must survive a round-trip: after the first load rewrites the tag to
    INFERRED (with the float in confidence_score), a second load of the persisted
    graph must stay silent and leave the score stable — otherwise the warning
    would just move one run later."""
    from networkx.readwrite import json_graph
    raw = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
                     {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"}],
           "links": [{"source": "n1", "target": "n2", "relation": "calls",
                      "confidence": 0.85, "source_file": "a.py"}]}
    G1 = build_from_json(raw)
    capsys.readouterr()
    # persist exactly as graph.json would, then reload
    persisted = json_graph.node_link_data(G1, edges="links")
    G2 = build_from_json(persisted)
    err = capsys.readouterr().err
    assert "invalid confidence" not in err
    d = edge_data(G2, "n1", "n2")
    assert d["confidence"] == "INFERRED"
    assert d["confidence_score"] == 0.85


def test_node_alias_canonical_field_wins():
    """#2194: when both the canonical field and its alias are present, the
    canonical value wins and the alias key is left untouched."""
    ext = {"nodes": [{"id": "n1", "label": "Real", "name": "Alias",
                      "file_type": "code", "source_file": "a.py"}],
           "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    assert G.nodes["n1"]["label"] == "Real"
    assert G.nodes["n1"]["name"] == "Alias"  # preserved, not consumed


def test_alias_node_ghost_merges_into_ast_twin():
    """#2194: an alias-only semantic node (name/path) must participate in the
    AST/LLM ghost merge once folded — same label and file as an AST node with a
    different id collapses into the AST node instead of surviving as a ghost."""
    ext = {"nodes": [
        {"id": "src_foo_helper", "label": "helper", "file_type": "code",
         "source_file": "src/foo.py", "_origin": "ast", "source_location": "L10"},
        {"id": "helper_ghost", "name": "helper", "path": "src/foo.py",
         "file_type": "code"},
    ], "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    assert "src_foo_helper" in G.nodes
    assert "helper_ghost" not in G.nodes
    assert G.number_of_nodes() == 1


def test_alias_node_gets_nonempty_norm_label(tmp_path):
    """#2194: a recovered alias node must serialize with a non-empty norm_label
    so query/explain can find it."""
    from graphify.export import to_json
    ext = {"nodes": [{"id": "n1", "name": "Foo", "path": "a/b.md", "file_type": "concept"}],
           "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext)
    out = tmp_path / "graph.json"
    assert to_json(G, {}, str(out))
    data = json.loads(out.read_text())
    node = next(n for n in data["nodes"] if n["id"] == "n1")
    assert node["norm_label"] == "foo"


def test_extraction_warning_breakdown_by_cause(capsys):
    """#2194: a mixed batch of schema errors must report per-cause counts, not
    just the first error."""
    ext = {"nodes": [
        {"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
        {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"},
        # two nodes missing label (and carrying no name alias)
        {"id": "x1", "file_type": "code", "source_file": "x.py"},
        {"id": "x2", "file_type": "code", "source_file": "x.py"},
    ], "edges": [
        # three edges missing relation (and carrying no type alias)
        {"source": "n1", "target": "n2", "confidence": "EXTRACTED", "source_file": "a.py"},
        {"source": "n2", "target": "n1", "confidence": "EXTRACTED", "source_file": "a.py"},
        {"source": "n1", "target": "x1", "confidence": "EXTRACTED", "source_file": "a.py"},
    ], "input_tokens": 0, "output_tokens": 0}
    build_from_json(ext)
    err = capsys.readouterr().err
    assert "2x missing required field 'label'" in err
    assert "3x missing required field 'relation'" in err


def test_absolute_derived_semantic_ids_rekeyed(tmp_path):
    """#2197: a semantic fragment whose ids were derived from an ABSOLUTE
    source_file (Windows detect() emits them) must re-key to the canonical
    repo-relative stem instead of ghosting against the existing graph."""
    from graphify.ids import make_id
    (tmp_path / "docs").mkdir()
    abs_sf = str(tmp_path / "docs" / "DATAFLOW.md")
    abs_stem = make_id(str(tmp_path / "docs" / "DATAFLOW"))
    ext = {"nodes": [
        {"id": abs_stem, "label": "DATAFLOW.md", "file_type": "document",
         "source_file": abs_sf},
        {"id": f"{abs_stem}_pipeline", "label": "Pipeline", "file_type": "concept",
         "source_file": abs_sf},
    ], "edges": [
        {"source": abs_stem, "target": f"{abs_stem}_pipeline", "relation": "describes",
         "confidence": "INFERRED", "source_file": abs_sf, "weight": 1.0},
    ], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext, root=tmp_path)
    assert "docs_dataflow" in G.nodes
    assert "docs_dataflow_pipeline" in G.nodes
    assert abs_stem not in G.nodes
    assert G.nodes["docs_dataflow"]["source_file"] == "docs/DATAFLOW.md"
    assert G.has_edge("docs_dataflow", "docs_dataflow_pipeline")


def test_absolute_derived_semantic_ids_rekeyed_backslash(tmp_path):
    """#2197 (separator variant): the same absolute-derived-id fragment with
    backslash separators in source_file re-keys identically."""
    from graphify.ids import make_id
    (tmp_path / "docs").mkdir()
    abs_sf = str(tmp_path / "docs" / "DATAFLOW.md").replace("/", "\\")
    abs_stem = make_id(str(tmp_path / "docs" / "DATAFLOW"))
    ext = {"nodes": [
        {"id": f"{abs_stem}_pipeline", "label": "Pipeline", "file_type": "concept",
         "source_file": abs_sf},
    ], "edges": [], "input_tokens": 0, "output_tokens": 0}
    G = build_from_json(ext, root=tmp_path)
    assert "docs_dataflow_pipeline" in G.nodes
    assert G.nodes["docs_dataflow_pipeline"]["source_file"] == "docs/DATAFLOW.md"


def test_source_file_backslash_normalized():
    """Windows backslash paths and POSIX paths for the same file must produce one node."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "code", "source_file": "src\\middleware\\auth.py"},
            {"id": "n2", "label": "B", "file_type": "code", "source_file": "src/middleware/auth.py"},
        ],
        "edges": [],
        "input_tokens": 0, "output_tokens": 0,
    }
    G = build_from_json(extraction)
    sources = {G.nodes[n]["source_file"] for n in G.nodes()}
    assert sources == {"src/middleware/auth.py"}


def test_edge_missing_source_file_backfilled_from_node():
    """#1279: a semantic/LLM edge lacking source_file must inherit it from its
    source node rather than reach graph.json with no file reference."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "concept", "source_file": "docs/a.md"},
            {"id": "n2", "label": "B", "file_type": "concept", "source_file": "docs/b.md"},
        ],
        # No source_file on the edge (as LLM output sometimes omits it).
        "edges": [{"source": "n1", "target": "n2", "relation": "relates_to", "confidence": "INFERRED"}],
        "input_tokens": 0, "output_tokens": 0,
    }
    G = build_from_json(extraction)
    sf = edge_data(G, "n1", "n2").get("source_file")
    assert sf == "docs/a.md"  # backfilled from the source node


def test_build_merges_multiple_extractions():
    ext1 = {"nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"}],
            "edges": [], "input_tokens": 0, "output_tokens": 0}
    ext2 = {"nodes": [{"id": "n2", "label": "B", "file_type": "document", "source_file": "b.md"}],
            "edges": [{"source": "n1", "target": "n2", "relation": "references",
                       "confidence": "INFERRED", "source_file": "b.md", "weight": 1.0}],
            "input_tokens": 0, "output_tokens": 0}
    G = build([ext1, ext2])
    assert G.number_of_nodes() == 2
    assert G.number_of_edges() == 1


def test_none_file_type_defaults_to_concept(capsys):
    """Legacy nodes with file_type=None (e.g. preserved from older graph.json
    by `_rebuild_code`) must not trigger 'invalid file_type None' warnings (#660)."""
    ext = {
        "nodes": [
            {"id": "n1", "label": "Stub", "file_type": None, "source_file": "a.py"},
            {"id": "n2", "label": "Real", "file_type": "code", "source_file": "b.py"},
        ],
        "edges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    G = build_from_json(ext)
    err = capsys.readouterr().err
    assert "invalid file_type" not in err
    # The legacy node still exists in the graph and has been canonicalized
    assert G.nodes["n1"]["file_type"] == "concept"
    assert G.nodes["n2"]["file_type"] == "code"


def test_missing_file_type_defaults_to_concept(capsys):
    """Nodes missing file_type entirely should also be canonicalized to 'concept'."""
    ext = {
        "nodes": [
            {"id": "n1", "label": "Bare", "source_file": "a.py"},
        ],
        "edges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    G = build_from_json(ext)
    err = capsys.readouterr().err
    assert "invalid file_type" not in err
    assert "missing required field 'file_type'" not in err
    assert G.nodes["n1"]["file_type"] == "concept"


def test_real_invalid_file_type_coerced_to_concept():
    """Unknown file_type values are coerced through the synonym mapper, falling
    back to 'concept' for anything that isn't a known LLM synonym (#840)."""
    ext = {
        "nodes": [
            {"id": "n1", "label": "Bad", "file_type": "weird_type", "source_file": "a.py"},
        ],
        "edges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    G = build_from_json(ext)
    assert G.nodes["n1"]["file_type"] == "concept"


def test_file_type_synonym_mapping():
    """Known invalid file_type values map to their canonical equivalents."""
    ext = {
        "nodes": [
            {"id": "n1", "label": "MD", "file_type": "markdown", "source_file": "a.md"},
            {"id": "n2", "label": "Tool", "file_type": "tool", "source_file": "b.py"},
            {"id": "n3", "label": "Pat", "file_type": "pattern", "source_file": "c.md"},
        ],
        "edges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    G = build_from_json(ext)
    assert G.nodes["n1"]["file_type"] == "document"
    assert G.nodes["n2"]["file_type"] == "code"
    assert G.nodes["n3"]["file_type"] == "concept"


def test_ghost_merge_unique_located_node_still_merges():
    """#1145 ghost-merge: a semantic ghost collapses into the single AST node
    sharing its (basename, label), and edges re-point to the AST node."""
    ext = {
        "nodes": [
            {"id": "ast_render", "label": "render", "file_type": "code",
             "source_file": "src/app/index.ts", "source_location": "L10", "_origin": "ast"},
            {"id": "ghost_render", "label": "render", "file_type": "code",
             "source_file": "src/app/index.ts"},
            {"id": "caller", "label": "main", "file_type": "code",
             "source_file": "src/main.ts", "source_location": "L1", "_origin": "ast"},
        ],
        "edges": [{"source": "caller", "target": "ghost_render", "relation": "calls",
                   "confidence": "EXTRACTED", "source_file": "src/main.ts", "weight": 1.0}],
        "input_tokens": 0, "output_tokens": 0,
    }
    G = build_from_json(ext)
    assert "ghost_render" not in G.nodes()
    assert G.has_edge("caller", "ast_render")


def test_ghost_merge_uses_source_file_not_basename():
    """#2068: the ghost-merge key is the full source_file, not the bare basename.
    A ghost from src/a/index.ts merges into THAT file's AST node (a_render), never
    the unrelated same-basename b_render in src/b/index.ts. (Pre-#2068 the
    (basename, label) key made ('index.ts','render') ambiguous and skipped the
    merge; the directory-aware key resolves it precisely.)"""
    ext = {
        "nodes": [
            {"id": "a_render", "label": "render", "file_type": "code",
             "source_file": "src/a/index.ts", "source_location": "L10", "_origin": "ast"},
            {"id": "b_render", "label": "render", "file_type": "code",
             "source_file": "src/b/index.ts", "source_location": "L20", "_origin": "ast"},
            {"id": "ghost_render", "label": "render", "file_type": "code",
             "source_file": "src/a/index.ts"},
            {"id": "caller", "label": "main", "file_type": "code",
             "source_file": "src/main.ts", "source_location": "L1", "_origin": "ast"},
        ],
        "edges": [{"source": "caller", "target": "ghost_render", "relation": "calls",
                   "confidence": "EXTRACTED", "source_file": "src/main.ts", "weight": 1.0}],
        "input_tokens": 0, "output_tokens": 0,
    }
    G = build_from_json(ext)
    # Ghost merges into its same-file twin; the edge re-points to a_render only.
    assert "ghost_render" not in G.nodes()
    assert G.has_edge("caller", "a_render")
    assert not G.has_edge("caller", "b_render")
    # The unrelated same-basename node in another directory is untouched.
    assert "b_render" in G.nodes()


def test_ghost_merge_not_across_directories_same_basename():
    """#2068: two unrelated non-AST nodes with the same basename+label in
    DIFFERENT directories must NOT be merged onto one survivor (the bug: bare
    basename collapsed docs/product_a/index.md and docs/product_b/index.md)."""
    ext = {
        "nodes": [
            {"id": "docs_a_index", "label": "Quickstart", "file_type": "document",
             "source_file": "docs/product_a/index.md", "source_location": "L1"},
            {"id": "docs_b_index", "label": "Quickstart", "file_type": "document",
             "source_file": "docs/product_b/index.md"},
            {"id": "docs_hub", "label": "Docs", "file_type": "concept",
             "source_file": "docs/hub.md", "source_location": "L1"},
        ],
        "edges": [{"source": "docs_hub", "target": "docs_b_index", "relation": "links_to",
                   "confidence": "INFERRED", "source_file": "docs/hub.md"}],
        "input_tokens": 0, "output_tokens": 0,
    }
    G = build_from_json(ext, directed=False)
    # Both docs survive; the edge stays on the file it was authored against.
    assert "docs_a_index" in G.nodes() and "docs_b_index" in G.nodes()
    assert G.has_edge("docs_hub", "docs_b_index")
    assert not G.has_edge("docs_hub", "docs_a_index")


def test_ghost_merge_non_ast_different_files_both_survive():
    """#1753: two NON-AST (semantic) nodes sharing (basename, label) but from
    DIFFERENT files are distinct concepts with no AST canonical twin. They must
    not be merged into an arbitrary survivor (which flipped run-to-run with the
    hash seed); both survive, mirroring the AST/AST guard (#1257)."""
    ext = {
        "nodes": [
            {"id": "dir_a_update_build_merge", "label": "build_merge() function",
             "file_type": "concept", "source_file": "dir_a/update.md", "source_location": "L10"},
            {"id": "dir_b_update_build_merge", "label": "build_merge() function",
             "file_type": "concept", "source_file": "dir_b/update.md", "source_location": "L12"},
        ],
        "edges": [],
    }
    G = build_from_json(ext, directed=False)
    assert sorted(G.nodes()) == ["dir_a_update_build_merge", "dir_b_update_build_merge"]


def test_ghost_merge_non_ast_same_file_still_merges():
    """A genuine duplicate — two non-AST nodes with the SAME source_file and
    label — is a real ghost and still collapses to one node (deterministically),
    so #1753's fix doesn't leave same-file LLM duplicates behind."""
    ext = {
        "nodes": [
            {"id": "a_foo", "label": "Foo", "file_type": "concept",
             "source_file": "x/doc.md", "source_location": "L1"},
            {"id": "b_foo", "label": "Foo", "file_type": "concept",
             "source_file": "x/doc.md", "source_location": "L2"},
        ],
        "edges": [],
    }
    G = build_from_json(ext, directed=False)
    assert G.number_of_nodes() == 1


def test_ghost_merge_wrong_source_file_resolved_by_label():
    """#3344: a semantic node that only MENTIONS a file (a saved
    graphify-out/memory/*.md query answer, a runbook narrating "see App.tsx")
    is stamped with source_file = the document being read, not the file named
    in its prose — so the (source_file, label) key can never match the real
    AST node's key. Resolve it by label alone against every AST file-self node
    (_is_file_node_label), including when the doc's prose dropped a leading
    path segment ("customer-app/index.ts" for the real
    "apps/customer-app/index.ts")."""
    ext = {
        "nodes": [
            {"id": "apps_customer_app_app", "label": "App.tsx", "file_type": "code",
             "source_file": "apps/customer-app/App.tsx", "source_location": "L1", "_origin": "ast"},
            {"id": "apps_customer_app_index", "label": "customer-app/index.ts", "file_type": "code",
             "source_file": "apps/customer-app/index.ts", "source_location": "L1", "_origin": "ast"},
            {"id": "app", "label": "App.tsx", "file_type": "code",
             "source_file": "graphify-out/memory/query_fake.md", "_origin": "semantic"},
            {"id": "customer_app_index", "label": "customer-app/index.ts", "file_type": "code",
             "source_file": "graphify-out/memory/query_fake.md", "_origin": "semantic"},
            {"id": "some_query_node", "label": "Query: why does X connect Y?", "file_type": "document",
             "source_file": "graphify-out/memory/query_fake.md", "_origin": "semantic"},
        ],
        "edges": [
            {"source": "some_query_node", "target": "app", "relation": "references",
             "confidence": "EXTRACTED", "source_file": "graphify-out/memory/query_fake.md"},
            {"source": "some_query_node", "target": "customer_app_index", "relation": "references",
             "confidence": "EXTRACTED", "source_file": "graphify-out/memory/query_fake.md"},
        ],
    }
    G = build_from_json(ext, directed=False)
    assert "app" not in G.nodes() and "customer_app_index" not in G.nodes()
    assert G.has_edge("some_query_node", "apps_customer_app_app")
    assert G.has_edge("some_query_node", "apps_customer_app_index")


def test_ghost_merge_wrong_source_file_ambiguous_basename_left_alone():
    """#3344: the label-alone fallback must stay conservative — a phantom
    mentioning a bare basename that TWO different real files share (an
    "index.ts" in two different directories) has no safe unique winner and
    must be left as-is rather than merged into an arbitrary one."""
    ext = {
        "nodes": [
            {"id": "apps_admin_web_index", "label": "index.ts", "file_type": "code",
             "source_file": "apps/admin-web/src/lib/index.ts", "source_location": "L1", "_origin": "ast"},
            {"id": "apps_api_index", "label": "index.ts", "file_type": "code",
             "source_file": "apps/api/src/lib/index.ts", "source_location": "L1", "_origin": "ast"},
            {"id": "phantom_index", "label": "index.ts", "file_type": "code",
             "source_file": "graphify-out/memory/query_fake2.md", "_origin": "semantic"},
        ],
        "edges": [],
    }
    G = build_from_json(ext, directed=False)
    assert "phantom_index" in G.nodes()
    assert "apps_admin_web_index" in G.nodes() and "apps_api_index" in G.nodes()


def test_build_merge_preserves_call_edge_direction(tmp_path):
    """Regression for #760.

    When the callee is defined before the caller in source, NetworkX's
    undirected Graph stores edges in node-insertion order. Going through
    node_link_graph() + edges() during build_merge previously flipped the
    `calls` edge so that on the next save source/target were swapped.

    build_merge must read the saved JSON's source/target verbatim instead
    of round-tripping through NetworkX.
    """
    from graphify.extract import extract_js
    from graphify.export import to_json

    # Callee `b` is defined before caller `a` so node insertion order
    # is b, a. An undirected Graph then yields the edge as (b, a) on
    # iteration, which is the wrong direction for `calls` (a calls b).
    src = "function b() {}\nfunction a() { b(); }\n"
    src_file = tmp_path / "x.js"
    src_file.write_text(src)

    extraction = extract_js(src_file)
    assert "error" not in extraction

    # Locate the `calls` edge in the raw extraction so we know the truth.
    call_edges = [e for e in extraction["edges"] if e["relation"] == "calls"]
    assert len(call_edges) == 1, "expected exactly one calls edge from the snippet"
    truth_src = call_edges[0]["source"]
    truth_tgt = call_edges[0]["target"]

    nodes_by_id = {n["id"]: n for n in extraction["nodes"]}
    assert nodes_by_id[truth_src]["label"].startswith("a")
    assert nodes_by_id[truth_tgt]["label"].startswith("b")

    # First build + save.
    G1 = build([extraction], dedup=False)
    graph_path = tmp_path / "graph.json"
    communities: dict = {}
    assert to_json(G1, communities, str(graph_path), force=True)

    # Verify direction is correct in the freshly written JSON.
    saved = json.loads(graph_path.read_text())
    saved_calls = [e for e in saved.get("links", saved.get("edges", []))
                   if e.get("relation") == "calls"]
    assert len(saved_calls) == 1
    assert saved_calls[0]["source"] == truth_src
    assert saved_calls[0]["target"] == truth_tgt

    # Now simulate `--update` with no new chunks — load + re-save.
    G2 = build_merge([], graph_path, dedup=False)
    assert to_json(G2, communities, str(graph_path), force=True)

    # The calls edge must still go a -> b, not b -> a.
    reloaded = json.loads(graph_path.read_text())
    reloaded_calls = [e for e in reloaded.get("links", reloaded.get("edges", []))
                      if e.get("relation") == "calls"]
    assert len(reloaded_calls) == 1
    assert reloaded_calls[0]["source"] == truth_src, (
        f"calls edge source flipped after build_merge round-trip: "
        f"expected {truth_src} (a), got {reloaded_calls[0]['source']}"
    )
    assert reloaded_calls[0]["target"] == truth_tgt, (
        f"calls edge target flipped after build_merge round-trip: "
        f"expected {truth_tgt} (b), got {reloaded_calls[0]['target']}"
    )


def test_build_merge_directed_edge_direction_survives_round_trip(tmp_path):
    """Regression for #2342: once build_merge correctly inherits the on-disk
    `directed` flag, the resulting graph must actually be a DiGraph whose
    edges are readable in the right direction (a -> b, not b -> a)."""
    from graphify.extract import extract_js
    from graphify.export import to_json

    src = "function b() {}\nfunction a() { b(); }\n"
    src_file = tmp_path / "x.js"
    src_file.write_text(src)

    extraction = extract_js(src_file)
    call_edges = [e for e in extraction["edges"] if e["relation"] == "calls"]
    assert len(call_edges) == 1
    truth_src = call_edges[0]["source"]
    truth_tgt = call_edges[0]["target"]

    G1 = build([extraction], directed=True, dedup=False)
    graph_path = tmp_path / "graph.json"
    assert to_json(G1, {}, str(graph_path), force=True)

    G2 = build_merge([], graph_path, dedup=False)
    assert G2.is_directed() is True
    assert G2.has_edge(truth_src, truth_tgt)
    assert not G2.has_edge(truth_tgt, truth_src)


def test_build_merge_inherits_directed_flag_from_disk(tmp_path):
    """Regression for #2342.

    build_merge with no explicit `directed=` must honor the on-disk graph's
    own `directed` flag instead of silently defaulting to False, or an
    incremental --update on a directed graph downgrades it to undirected.
    """
    ext = {
        "nodes": [{"id": "a", "label": "a", "file_type": "concept",
                   "source_file": "x.md", "source_location": "L1"}],
        "edges": [],
    }
    from graphify.export import to_json

    graph_path = tmp_path / "graph.json"

    # Directed graph on disk -> no directed= kwarg -> stays directed.
    G1 = build([ext], directed=True, dedup=False)
    assert to_json(G1, {}, str(graph_path), force=True)
    G2 = build_merge([], graph_path, dedup=False)
    assert G2.is_directed() is True
    saved = json.loads(graph_path.read_text())
    assert saved.get("directed") is True

    # Undirected graph on disk -> no directed= kwarg -> stays undirected (no regression).
    G3 = build([ext], directed=False, dedup=False)
    assert to_json(G3, {}, str(graph_path), force=True)
    G4 = build_merge([], graph_path, dedup=False)
    assert G4.is_directed() is False


def test_build_merge_fresh_graph_defaults_undirected(tmp_path):
    """No existing graph.json + no directed= kwarg -> falls back to the
    current default (False), same as before #2342."""
    graph_path = tmp_path / "does_not_exist.json"
    G = build_merge([], graph_path, dedup=False)
    assert G.is_directed() is False


def test_build_merge_explicit_directed_overrides_disk_flag(tmp_path):
    """An explicit directed=True/False from the caller must still win over
    whatever is stored on disk (#2342)."""
    ext = {
        "nodes": [{"id": "a", "label": "a", "file_type": "concept",
                   "source_file": "x.md", "source_location": "L1"}],
        "edges": [],
    }
    from graphify.export import to_json

    graph_path = tmp_path / "graph.json"

    # Directed on disk, explicit directed=False -> caller wins.
    G1 = build([ext], directed=True, dedup=False)
    assert to_json(G1, {}, str(graph_path), force=True)
    G2 = build_merge([], graph_path, directed=False, dedup=False)
    assert G2.is_directed() is False

    # Undirected on disk, explicit directed=True -> caller wins.
    G3 = build([ext], directed=False, dedup=False)
    assert to_json(G3, {}, str(graph_path), force=True)
    G4 = build_merge([], graph_path, directed=True, dedup=False)
    assert G4.is_directed() is True


def test_build_from_json_preserves_first_direction_on_bidirectional_pair(tmp_path):
    """Regression for #1061.

    When an extraction emits two `calls` edges between the same pair in
    opposite directions (mutual recursion, callbacks, event handlers, etc.),
    nx.Graph collapses them into a single undirected edge. The deterministic
    edge sort introduced in #1010 ordered edges by (source, target, relation),
    so the lexicographically-later direction always wrote second and clobbered
    the first edge's _src/_tgt — the surviving edge then exported with caller
    and callee systematically swapped on every collision.

    build_from_json must keep the first-seen direction for the surviving edge
    instead of letting the second add_edge overwrite _src/_tgt.
    """
    from graphify.export import to_json

    # Lexicographic order of (src, tgt, rel) puts `a` < `z` first, so the sort
    # processes `a -> z` BEFORE `z -> a`. Without the fix, the second write
    # overwrites _src/_tgt and the exported edge becomes z -> a. With the fix,
    # the first-seen `a -> z` direction is preserved.
    extraction = {
        "nodes": [
            {"id": "a_handler", "label": "a", "file_type": "code", "source_file": "a.ts"},
            {"id": "z_emitter", "label": "z", "file_type": "code", "source_file": "z.ts"},
        ],
        "edges": [
            {"source": "a_handler", "target": "z_emitter", "relation": "calls",
             "confidence": "EXTRACTED", "source_file": "a.ts"},
            {"source": "z_emitter", "target": "a_handler", "relation": "calls",
             "confidence": "EXTRACTED", "source_file": "z.ts"},
        ],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    G = build_from_json(extraction)
    # Only one undirected edge between the pair survives, but its stored
    # direction must be the first-seen one (a_handler -> z_emitter), not the
    # lexicographically-later one (z_emitter -> a_handler).
    assert G.number_of_edges() == 1
    data = edge_data(G, "a_handler", "z_emitter")
    assert data["_src"] == "a_handler"
    assert data["_tgt"] == "z_emitter"

    graph_path = tmp_path / "graph.json"
    assert to_json(G, {}, str(graph_path), force=True)
    saved = json.loads(graph_path.read_text())
    saved_calls = [e for e in saved.get("links", saved.get("edges", []))
                   if e.get("relation") == "calls"]
    assert len(saved_calls) == 1
    assert saved_calls[0]["source"] == "a_handler", (
        f"calls edge source flipped on bidirectional collision: "
        f"expected a_handler, got {saved_calls[0]['source']}"
    )
    assert saved_calls[0]["target"] == "z_emitter", (
        f"calls edge target flipped on bidirectional collision: "
        f"expected z_emitter, got {saved_calls[0]['target']}"
    )


# Regression tests for #796 — edge_data / edge_datas helpers must tolerate
# MultiGraph and MultiDiGraph, which networkx's node_link_graph() produces
# whenever the loaded JSON has multigraph: true. Plain G.edges[u, v] crashes
# on those with `ValueError: not enough values to unpack (expected 3, got 2)`.

def test_edge_data_simple_graph():
    G = nx.Graph()
    G.add_edge("a", "b", relation="calls", confidence="EXTRACTED")
    d = edge_data(G, "a", "b")
    assert isinstance(d, dict)
    assert d["relation"] == "calls"
    assert d["confidence"] == "EXTRACTED"


def test_edge_datas_simple_graph_returns_singleton_list():
    G = nx.Graph()
    G.add_edge("a", "b", relation="calls", confidence="EXTRACTED")
    ds = edge_datas(G, "a", "b")
    assert isinstance(ds, list)
    assert len(ds) == 1
    assert ds[0]["relation"] == "calls"


def test_edge_data_multigraph_with_parallel_edges():
    G = nx.MultiGraph()
    G.add_edge("a", "b", relation="calls", confidence="EXTRACTED")
    G.add_edge("a", "b", relation="references", confidence="INFERRED")
    d = edge_data(G, "a", "b")
    assert isinstance(d, dict)
    # First parallel edge wins; should be one of the two attribute dicts above.
    assert d.get("relation") in ("calls", "references")


def test_edge_datas_multigraph_returns_all_parallel_edges():
    G = nx.MultiGraph()
    G.add_edge("a", "b", relation="calls", confidence="EXTRACTED")
    G.add_edge("a", "b", relation="references", confidence="INFERRED")
    ds = edge_datas(G, "a", "b")
    assert isinstance(ds, list)
    assert len(ds) == 2
    relations = {e.get("relation") for e in ds}
    assert relations == {"calls", "references"}


def test_edge_data_multidigraph():
    G = nx.MultiDiGraph()
    G.add_edge("a", "b", relation="calls")
    G.add_edge("a", "b", relation="imports")
    d = edge_data(G, "a", "b")
    assert isinstance(d, dict)
    assert d.get("relation") in ("calls", "imports")
    ds = edge_datas(G, "a", "b")
    assert len(ds) == 2


def test_edge_data_node_link_multigraph_roundtrip():
    """A node_link JSON with multigraph: true must load as MultiGraph and the
    helpers must operate on it without raising the 3-tuple unpack ValueError."""
    data = {
        "directed": False,
        "multigraph": True,
        "graph": {},
        "nodes": [
            {"id": "a", "label": "A"},
            {"id": "b", "label": "B"},
        ],
        "links": [
            {"source": "a", "target": "b", "relation": "calls", "confidence": "EXTRACTED"},
            {"source": "a", "target": "b", "relation": "references", "confidence": "INFERRED"},
        ],
    }
    try:
        G = json_graph.node_link_graph(data, edges="links")
    except TypeError:
        G = json_graph.node_link_graph(data)
    assert isinstance(G, nx.MultiGraph)
    # Plain G.edges[u, v] would raise here; the helper must not.
    d = edge_data(G, "a", "b")
    assert isinstance(d, dict)
    assert d.get("relation") in ("calls", "references")
    ds = edge_datas(G, "a", "b")
    assert len(ds) == 2


def test_build_from_json_relativizes_absolute_source_file(tmp_path):
    """Semantic subagents emit absolute source_file paths; build_from_json must
    relativize them to root so MCP traversal works correctly (#932)."""
    root = tmp_path / "myproject"
    root.mkdir()
    abs_path = str(root / "docs" / "overview.md")
    extraction = {
        "nodes": [
            {"id": "overview_intro", "label": "Intro", "source_file": abs_path, "file_type": "document"},
        ],
        "edges": [
            {"source": "overview_intro", "target": "overview_intro",
             "relation": "self", "confidence": "EXTRACTED", "confidence_score": 1.0,
             "source_file": abs_path},
        ],
    }
    G = build_from_json(extraction, root=root)
    # The id-stem migration (#1504) re-keys the old short id to the full-path form.
    sf = G.nodes["docs_overview_intro"]["source_file"]
    assert not sf.startswith("/"), f"source_file still absolute: {sf}"
    assert sf == "docs/overview.md"


def test_build_relativizes_absolute_source_file(tmp_path):
    """build() passes root through to build_from_json (#932)."""
    root = tmp_path / "proj"
    root.mkdir()
    abs_path = str(root / "src" / "main.py")
    extraction = {
        "nodes": [{"id": "main_fn", "label": "main", "source_file": abs_path, "file_type": "code"}],
        "edges": [],
    }
    G = build([extraction], root=root)
    # #1504 re-keys main_fn (old stem "main") to the full-path form "src_main".
    sf = G.nodes["src_main_fn"]["source_file"]
    assert sf == "src/main.py"


def test_build_from_json_ambiguous_old_stem_alias_stays_dangling(tmp_path):
    """The #1504 old-stem alias (e.g. "ping.h" -> bare "ping") is meant to let a
    stale-id edge from an un-re-extracted fragment still find its own file after
    a rekey. But the old-stem form drops the extension and most of the path, so
    two unrelated real files easily collapse onto the same bare alias (a C header
    and a PHP script both named "ping", in different directories). A dangling
    edge produced by an unrelated third file's own unscoped fallback id (e.g. the
    C/C++ extractor's last-resort target for an #include it couldn't resolve to
    a real path) must not silently ride that alias onto an arbitrary one of them
    — it should stay dangling and get dropped, same as any other unresolvable
    edge, rather than wire two unrelated files/languages together by accident."""
    root = tmp_path / "repo"
    root.mkdir()
    extraction = {
        "nodes": [
            # Ids given in their canonical (post-extract.py, extension-stripped)
            # form, matching what a real graphify update run would already have
            # produced before build_from_json assembles the final graph.
            {"id": "dev_monitoring_ping", "label": "ping.h", "file_type": "code",
             "source_file": "Dev/monitoring/ping.h"},
            {"id": "www_pages_api_ping", "label": "ping.php", "file_type": "code",
             "source_file": "www/pages/api/ping.php"},
            {"id": "dev_poker_server", "label": "server.cpp", "file_type": "code",
             "source_file": "Dev/poker/server.cpp"},
        ],
        "edges": [
            # The unscoped, deliberately-unresolved fallback edge a C/C++ #include
            # resolver leaves behind when it can't find the header on disk.
            {"source": "dev_poker_server", "target": "ping", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "Dev/poker/server.cpp"},
        ],
    }
    G = build_from_json(extraction, root=root)
    assert not G.has_edge("dev_poker_server", "dev_monitoring_ping")
    assert not G.has_edge("dev_poker_server", "www_pages_api_ping")


def test_build_from_json_ambiguous_alias_detected_despite_header_impl_salting(tmp_path):
    """A same-directory .h/.cpp pair collides on their shared pre-extension id
    and gets salted apart into ids like "tools_aolserver_utility_h_..." — no
    longer a clean new_stem prefix. The ambiguity check must still recognize
    the salted header as a legitimate claimant for the bare old-stem alias (by
    label, not id shape), so a real collision with an unrelated same-named PHP
    file is still caught instead of the header silently dropping out of the
    race and leaving the PHP file as the lone "unambiguous" winner (this
    reproduced against the real depot: Tools/aolserver/utility.h and .cpp,
    salted apart, let wwwapi.masque.com/pages/utility.php win the bare
    "utility" alias uncontested)."""
    root = tmp_path / "repo"
    root.mkdir()
    extraction = {
        "nodes": [
            {"id": "tools_aolserver_utility_h_tools_aolserver_utility", "label": "utility.h",
             "file_type": "code", "source_file": "Tools/aolserver/utility.h"},
            {"id": "tools_aolserver_utility_cpp_tools_aolserver_utility", "label": "utility.cpp",
             "file_type": "code", "source_file": "Tools/aolserver/utility.cpp"},
            {"id": "wwwapi_masque_com_pages_utility", "label": "utility.php",
             "file_type": "code", "source_file": "wwwapi.masque.com/pages/utility.php"},
            {"id": "dev_poker_server", "label": "server.cpp", "file_type": "code",
             "source_file": "Dev/poker/server.cpp"},
        ],
        "edges": [
            {"source": "dev_poker_server", "target": "utility", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "Dev/poker/server.cpp"},
        ],
    }
    G = build_from_json(extraction, root=root)
    assert not G.has_edge("dev_poker_server", "wwwapi_masque_com_pages_utility")
    assert not G.has_edge("dev_poker_server", "tools_aolserver_utility_h_tools_aolserver_utility")


def test_build_from_json_unambiguous_old_stem_alias_still_resolves(tmp_path):
    """Companion to the ambiguous case above: when exactly one real file claims
    an old-stem alias, a dangling edge to that bare alias should still resolve
    to it — the #1504 migration-compat behavior this index exists for."""
    root = tmp_path / "repo"
    root.mkdir()
    extraction = {
        "nodes": [
            {"id": "dev_monitoring_utility", "label": "utility.h", "file_type": "code",
             "source_file": "Dev/monitoring/utility.h"},
            {"id": "dev_poker_server", "label": "server.cpp", "file_type": "code",
             "source_file": "Dev/poker/server.cpp"},
        ],
        "edges": [
            {"source": "dev_poker_server", "target": "utility", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "Dev/poker/server.cpp"},
        ],
    }
    G = build_from_json(extraction, root=root)
    assert G.has_edge("dev_poker_server", "dev_monitoring_utility")


def test_build_from_json_relative_source_file_unchanged(tmp_path):
    """Already-relative source_file paths must not be modified."""
    extraction = {
        "nodes": [{"id": "foo_bar", "label": "bar", "source_file": "src/foo.py", "file_type": "code"}],
        "edges": [],
    }
    G = build_from_json(extraction, root=tmp_path)
    # source_file must be untouched; the id is re-keyed to the full-path form (#1504).
    assert G.nodes["src_foo_bar"]["source_file"] == "src/foo.py"


def test_build_merge_prune_absolute_paths_match_relative_nodes(tmp_path):
    """#1007: manifest stores absolute paths, graph nodes store relative paths.
    prune_sources with absolute paths must still remove the right nodes and edges."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    # Simulate a graph with relative source_file paths (as built normally)
    chunk = {"nodes": [
        {"id": "n1", "label": "login", "file_type": "code", "source_file": "module_a/auth.py"},
        {"id": "n2", "label": "format_date", "file_type": "code", "source_file": "module_b/utils.py"},
    ], "edges": [
        {"source": "n1", "target": "n2", "relation": "calls", "confidence": "EXTRACTED",
         "source_file": "module_b/utils.py", "weight": 1.0},
    ]}
    G0 = build([chunk], dedup=False)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # prune_sources from manifest — absolute paths (what detect_incremental emits)
    deleted_abs = [str(root / "module_b" / "utils.py")]
    G1 = build_merge([], graph_path, prune_sources=deleted_abs, dedup=False, root=root)

    node_labels = {d["label"] for _, d in G1.nodes(data=True)}
    assert "format_date" not in node_labels, "stale node from deleted file should be pruned"
    assert "login" in node_labels, "unrelated node must survive"
    # Edge from deleted file must also be gone
    assert G1.number_of_edges() == 0, "edge from deleted source_file should be pruned"


def test_build_merge_prune_windows_backslash_paths(tmp_path):
    """#1007: prune_sources with Windows-style backslash absolute paths must still match."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    chunk = {"nodes": [
        {"id": "n1", "label": "parse_date", "file_type": "code", "source_file": "module_b/utils.py"},
    ], "edges": []}
    G0 = build([chunk], dedup=False)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # Simulate Windows manifest path with backslashes
    win_path = str(root / "module_b" / "utils.py").replace("/", "\\")
    G1 = build_merge([], graph_path, prune_sources=[win_path], dedup=False, root=root)

    node_labels = {d["label"] for _, d in G1.nodes(data=True)}
    assert "parse_date" not in node_labels, "node should be pruned even with backslash path"


def test_build_merge_replaces_changed_file_stale_edges(tmp_path):
    """Re-extracting a CHANGED file must REPLACE its prior nodes/edges, not
    accumulate them. build_merge previously only grew the graph, so an edge that
    disappeared from a file's new version survived forever (only exact-duplicate
    edges collapsed). The new-chunk source_file may be an absolute win32 path
    while the stored graph keeps relative posix — both forms must match."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    # First build: changed.md contributed A, B and edge A->B; keep.md is unrelated.
    chunk0 = {"nodes": [
        {"id": "A", "label": "A", "file_type": "document", "source_file": "changed.md"},
        {"id": "B", "label": "B", "file_type": "document", "source_file": "changed.md"},
        {"id": "K", "label": "K", "file_type": "document", "source_file": "keep.md"},
    ], "edges": [
        {"source": "A", "target": "B", "relation": "references", "confidence": "EXTRACTED",
         "source_file": "changed.md", "weight": 1.0},
        {"source": "K", "target": "A", "relation": "references", "confidence": "EXTRACTED",
         "source_file": "keep.md", "weight": 1.0},
    ]}
    G0 = build([chunk0], dedup=False)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # changed.md edited: re-extraction now yields A, C and edge A->C (B dropped).
    # source_file arrives as an absolute win32-style path (as detect emits on Windows).
    abs_changed = str(root / "changed.md").replace("/", "\\")
    new_chunk = {"nodes": [
        {"id": "A", "label": "A", "file_type": "document", "source_file": abs_changed},
        {"id": "C", "label": "C", "file_type": "document", "source_file": abs_changed},
    ], "edges": [
        {"source": "A", "target": "C", "relation": "references", "confidence": "EXTRACTED",
         "source_file": abs_changed, "weight": 1.0},
    ]}
    G1 = build_merge([new_chunk], graph_path, dedup=False, root=root)

    labels = {d["label"] for _, d in G1.nodes(data=True)}
    edges = {(u, v) for u, v in G1.edges()}

    # Stale contribution from the old version of changed.md is gone.
    assert "B" not in labels, "stale node from changed file's old version must be dropped"
    assert ("A", "B") not in edges and ("B", "A") not in edges, "stale edge must be dropped"
    # Fresh contribution is present.
    assert "C" in labels, "re-extracted node must be present"
    assert ("A", "C") in edges, "re-extracted edge must be present"
    # An unchanged file is untouched.
    assert "K" in labels, "unchanged file's node must survive"
    assert ("K", "A") in edges, "unchanged file's edge must survive"


def _write_two_tier_graph(graph_path):
    """A graph where docs/readme.md carries BOTH tiers (#2333 COEXIST): an
    AST layer (document/heading nodes + a contains edge, _origin=ast) and a
    semantic layer (an unstamped concept node, source_location=None)."""
    data = {
        "directed": False,
        "nodes": [
            {"id": "docs_readme", "label": "Readme", "file_type": "document",
             "source_file": "docs/readme.md", "source_location": "L1",
             "_origin": "ast"},
            {"id": "docs_readme_intro", "label": "Intro", "file_type": "document",
             "source_file": "docs/readme.md", "source_location": "L3",
             "_origin": "ast"},
            {"id": "auth_flow", "label": "Auth Flow", "file_type": "concept",
             "source_file": "docs/readme.md", "source_location": None},
        ],
        "links": [
            {"source": "docs_readme", "target": "docs_readme_intro",
             "relation": "contains", "confidence": "EXTRACTED",
             "source_file": "docs/readme.md", "source_location": "L3",
             "weight": 1.0, "_origin": "ast"},
        ],
        "hyperedges": [
            {"id": "auth_group", "label": "Auth Group",
             "nodes": ["docs_readme", "auth_flow"], "relation": "form",
             "confidence": "INFERRED", "source_file": "docs/readme.md"},
        ],
    }
    graph_path.write_text(json.dumps(data), encoding="utf-8")


def test_build_merge_semantic_reextract_preserves_ast_layer(tmp_path):
    """#2333/#2336 (COEXIST): a semantic-only re-extract of a file replaces
    only that file's SEMANTIC tier — its AST document/heading nodes and AST
    edges must survive. Before the fix, replace-by-source was tier-blind and
    the semantic chunk deleted the doc's AST layer."""
    graph_path = tmp_path / "graph.json"
    _write_two_tier_graph(graph_path)

    # Semantic-only chunk for the same file: no _origin, null source_location
    # (the extraction-spec shape — the semantic path never stamps _origin).
    chunk = {"nodes": [
        {"id": "session_model", "label": "Session Model", "file_type": "concept",
         "source_file": "docs/readme.md", "source_location": None},
    ], "edges": []}
    G = build_merge([chunk], graph_path, dedup=False)

    assert "docs_readme" in G and "docs_readme_intro" in G, (
        "AST layer deleted by a semantic-only re-extract of the same file"
    )
    assert G.has_edge("docs_readme", "docs_readme_intro"), (
        "AST contains edge deleted by a semantic-only re-extract"
    )
    assert "auth_flow" not in G, "old semantic node must be replaced"
    assert "session_model" in G, "new semantic node must be present"


def test_build_merge_ast_reextract_preserves_semantic_layer(tmp_path):
    """#2333/#2336 inverse: an AST-only re-extract of a file replaces only
    that file's AST tier — its semantic concept nodes (and semantic-tier
    hyperedges, which an AST pass cannot regenerate) must survive."""
    graph_path = tmp_path / "graph.json"
    _write_two_tier_graph(graph_path)

    # AST-only re-extract: the doc changed — Intro heading replaced by
    # Quickstart. extract() always stamps _origin=ast.
    chunk = {"nodes": [
        {"id": "docs_readme", "label": "Readme", "file_type": "document",
         "source_file": "docs/readme.md", "source_location": "L1",
         "_origin": "ast"},
        {"id": "docs_readme_quickstart", "label": "Quickstart",
         "file_type": "document", "source_file": "docs/readme.md",
         "source_location": "L5", "_origin": "ast"},
    ], "edges": [
        {"source": "docs_readme", "target": "docs_readme_quickstart",
         "relation": "contains", "confidence": "EXTRACTED",
         "source_file": "docs/readme.md", "source_location": "L5",
         "weight": 1.0, "_origin": "ast"},
    ]}
    G = build_merge([chunk], graph_path, dedup=False)

    assert "auth_flow" in G, (
        "semantic layer deleted by an AST-only re-extract of the same file"
    )
    assert "docs_readme_intro" not in G, "stale AST node must be replaced"
    assert "docs_readme_quickstart" in G, "fresh AST node must be present"
    assert G.has_edge("docs_readme", "docs_readme_quickstart")
    carried_he_ids = {he.get("id") for he in G.graph.get("hyperedges", [])}
    assert "auth_group" in carried_he_ids, (
        "semantic-tier hyperedge dropped by an AST-only re-extract (#2336)"
    )


def test_merge_raw_extraction_tier_scoped(tmp_path):
    """#2333 raw-path mirror: merge_raw_extraction (extract --no-cluster
    incremental) applies the same tier-scoped replace as build_merge — a
    semantic-only re-extract keeps the file's AST nodes/edges."""
    from graphify.build import merge_raw_extraction

    graph_path = tmp_path / "graph.json"
    _write_two_tier_graph(graph_path)

    new = {"nodes": [
        {"id": "session_model", "label": "Session Model", "file_type": "concept",
         "source_file": "docs/readme.md", "source_location": None},
    ], "edges": [], "input_tokens": 0, "output_tokens": 0}
    out = merge_raw_extraction(new, graph_path)

    node_ids = {n["id"] for n in out["nodes"]}
    assert {"docs_readme", "docs_readme_intro", "session_model"} <= node_ids, (
        "AST layer dropped by a semantic-only raw re-extract"
    )
    assert "auth_flow" not in node_ids, "old semantic node must be replaced"
    edge_keys = {(e.get("source"), e.get("target")) for e in out["edges"]}
    assert ("docs_readme", "docs_readme_intro") in edge_keys, (
        "AST edge dropped by a semantic-only raw re-extract"
    )
    he_ids = {he.get("id") for he in out.get("hyperedges", [])}
    assert "auth_group" not in he_ids, (
        "semantic-tier hyperedge must be replaced by a semantic re-extract"
    )


def test_is_ast_tier_legacy_fallback():
    """#2334: _origin wins when present; unstamped legacy items fall back to
    the source_location shape (AST emits 'L<line>', semantic emits null)."""
    from graphify.build import _is_ast_tier

    assert _is_ast_tier({"_origin": "ast"}) is True
    assert _is_ast_tier({"_origin": "ast", "source_location": None}) is True
    assert _is_ast_tier({"source_location": "L10"}) is True
    assert _is_ast_tier({"source_location": None}) is False
    assert _is_ast_tier({}) is False
    assert _is_ast_tier({"_origin": "semantic", "source_location": "L10"}) is False


def test_build_merge_root_collapses_convention_drift(tmp_path):
    """Skill contract: the extraction subagent must emit source_file as the
    verbatim path from FILE_LIST AND the caller must pass root= (the build root).
    Then build_merge canonicalizes the new chunk to the same relative base as the
    stored graph, so re-extraction REPLACES the prior node (incl. stale nodes for
    that file) instead of accumulating a duplicate. Without root, a drifted
    relative base (e.g. a bare basename from a different run) mismatches and the
    graph duplicates. Engine is unchanged — this pins the prompt/root contract."""
    import networkx as nx

    root = tmp_path
    graph_path = tmp_path / "graphify-out" / "graph.json"
    graph_path.parent.mkdir(parents=True)

    # Stored graph: nested project-relative convention + a STALE node for the same
    # file that the re-extraction no longer emits.
    stored = {"nodes": [
        {"id": "wiki_overview_overview", "label": "Overview", "file_type": "document",
         "source_file": "docs/wiki/overview.md"},
        {"id": "wiki_overview_stale", "label": "Stale", "file_type": "document",
         "source_file": "docs/wiki/overview.md"},
    ], "edges": []}
    G0 = build([stored], dedup=False)
    saved = json.dumps(nx.node_link_data(G0, edges="edges"))
    graph_path.write_text(saved, encoding="utf-8")

    # BUG: --update drifted to a bare basename and no root was passed. Different
    # base -> source_file replace misses -> stale + duplicate both survive.
    drift = {"nodes": [
        {"id": "overview_overview", "label": "Overview", "file_type": "document",
         "source_file": "overview.md"},
    ], "edges": []}
    G_bug = build_merge([drift], graph_path, dedup=False)
    assert G_bug.number_of_nodes() == 3, "mismatched base must NOT replace -> stale+dup remain"

    # FIX: subagent emits the verbatim path; caller passes root (the build root).
    graph_path.write_text(saved, encoding="utf-8")
    abs_overview = str(root / "docs" / "wiki" / "overview.md")
    fixed = {"nodes": [
        {"id": "wiki_overview_overview", "label": "Overview", "file_type": "document",
         "source_file": abs_overview},
    ], "edges": []}
    G_ok = build_merge([fixed], graph_path, prune_sources=None, dedup=False, root=root)
    assert G_ok.number_of_nodes() == 1, "verbatim path + root must collapse to one node"
    # #1504 re-keys the author-chosen short ids to the canonical full-path stem.
    assert "docs_wiki_overview_stale" not in G_ok, "stale node for the re-extracted file must be dropped"
    assert G_ok.nodes["docs_wiki_overview_overview"]["source_file"] == "docs/wiki/overview.md", \
        "new chunk must be canonicalized to the stored relative base"


def test_build_merge_rejects_oversized_existing_graph(monkeypatch, tmp_path):
    """#F4: build_merge must refuse to read an existing graph.json that
    exceeds the size cap, rather than json.loads-ing it into memory."""
    import pytest

    graph_path = tmp_path / "graph.json"
    graph_path.write_text(json.dumps({"nodes": [], "links": []}), encoding="utf-8")
    monkeypatch.setattr("graphify.security._MAX_GRAPH_FILE_BYTES", 8)
    with pytest.raises(ValueError, match="exceeds"):
        build_merge([], graph_path, dedup=False)


def test_build_from_json_skips_non_hashable_node_id():
    # A malformed LLM extraction can emit a list-valued id; build_from_json must
    # skip it (NetworkX add_node would otherwise raise unhashable type) and still
    # build the graph from the well-formed nodes.
    extraction = {
        "nodes": [
            {"id": "a", "label": "A", "file_type": "code", "source_file": "a.py"},
            {"id": ["x", "y"], "label": "B", "file_type": "code", "source_file": "b.py"},
            {"label": "C", "file_type": "code", "source_file": "c.py"},  # missing id
        ],
        "edges": [],
    }
    G = build_from_json(extraction)
    assert set(G.nodes()) == {"a"}


def test_build_from_json_skips_edge_with_non_hashable_endpoint():
    # A list-valued edge endpoint must be skipped rather than crash the
    # `not in node_set` membership test. The well-formed edge survives.
    extraction = {
        "nodes": [
            {"id": "a", "label": "A", "file_type": "code", "source_file": "a.py"},
            {"id": "b", "label": "B", "file_type": "code", "source_file": "b.py"},
        ],
        "edges": [
            {"source": "a", "target": ["b", "c"], "relation": "calls",
             "confidence": "INFERRED", "source_file": "a.py"},
            {"source": "a", "target": "b", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "a.py"},
        ],
    }
    G = build_from_json(extraction)
    assert G.number_of_nodes() == 2
    assert G.number_of_edges() == 1
    assert G.has_edge("a", "b")


# ── #1504 migration: legacy-id detection + re-key source_file contract ──────────

def test_graph_has_legacy_ids_detects_old_scheme():
    """The read-only-consumer nudge (query/serve) flags a pre-#1504 graph and
    leaves a canonical one alone."""
    from graphify.build import graph_has_legacy_ids
    old = [{"id": "api_readme", "source_file": "docs/v1/api/README.md", "type": "document", "source_location": "L1"}]
    new = [{"id": "docs_v1_api_readme", "source_file": "docs/v1/api/README.md", "type": "document", "source_location": "L1"}]
    assert graph_has_legacy_ids(old, root=".") is True
    assert graph_has_legacy_ids(new, root=".") is False
    # sourceless / top-level file nodes don't false-positive
    assert graph_has_legacy_ids([{"id": "setup", "source_file": "setup.py", "source_location": "L1"}], root=".") is False
    assert graph_has_legacy_ids([{"id": "x", "label": "y"}], root=".") is False
    # package/dir-scoped SYMBOL ids (Go's _make_id(pkg_dir, name) -> "sub_thing") must
    # NOT false-positive: not file-level (no L1), so ignored even though "sub_thing"
    # coincides with the old file-stem form of pkg/sub/thing.go.
    go_symbol = [{"id": "sub_thing", "source_file": "pkg/sub/thing.go", "type": "code", "source_location": "L3"}]
    assert graph_has_legacy_ids(go_symbol, root=".") is False


# ── #2408: globally-scoped MCP node ids are not file-stem derived ──────────────

@pytest.mark.parametrize("mcp_kind, nid", [
    ("mcp_command", "mcp_command_npx"),
    ("mcp_package", "mcp_package_google_cloud_cloud_run_mcp"),
    ("env_var", "env_var_google_cloud_project"),
])
def test_graph_has_legacy_ids_ignores_global_mcp_ids(mcp_kind, nid):
    """MCP ingest stamps every node with L1 (JSON has no line info), so global ids
    would otherwise be read as file-level. Under `sub/.mcp.json` the old bare stem
    is `mcp`, which these ids legitimately start with (#2408)."""
    from graphify.build import graph_has_legacy_ids
    node = {
        "id": nid,
        "source_file": "sub/.mcp.json",
        "source_location": "L1",
        "metadata": {"mcp_kind": mcp_kind},
    }
    assert graph_has_legacy_ids([node], root=".") is False


def test_graph_has_legacy_ids_still_checks_file_scoped_mcp_nodes():
    """The exemption is narrow: file-derived MCP kinds stay under detection, and a
    missing/malformed metadata blob doesn't exempt anything (or crash)."""
    from graphify.build import graph_has_legacy_ids
    for kind in ("mcp_config_file", "mcp_server"):
        stale = {"id": "mcp_mcp_server_x", "source_file": "sub/.mcp.json",
                 "source_location": "L1", "metadata": {"mcp_kind": kind}}
        assert graph_has_legacy_ids([stale], root=".") is True
    for meta in (None, "not-a-dict", {}, {"mcp_kind": None}):
        stale = {"id": "mcp_mcp_server_x", "source_file": "sub/.mcp.json",
                 "source_location": "L1", "metadata": meta}
        assert graph_has_legacy_ids([stale], root=".") is True


@pytest.mark.parametrize("mcp_dir", ["", "sub"])
def test_fresh_mcp_graph_is_not_flagged_legacy(tmp_path, monkeypatch, mcp_dir):
    """End-to-end: a freshly extracted graph containing a .mcp.json — nested or at
    the repo root — must not nudge the user to rebuild (#2408)."""
    from graphify.build import graph_has_legacy_ids
    from graphify.extract import extract

    (tmp_path / "main.py").write_text("def main():\n    return 1\n")
    mcp_parent = tmp_path / mcp_dir if mcp_dir else tmp_path
    mcp_parent.mkdir(parents=True, exist_ok=True)
    (mcp_parent / ".mcp.json").write_text(json.dumps({"mcpServers": {"cloud-run": {
        "command": "npx",
        "args": ["-y", "@google-cloud/cloud-run-mcp"],
        "env": {"GOOGLE_CLOUD_PROJECT": "x"},
    }}}))

    monkeypatch.chdir(tmp_path)
    rel = Path(mcp_dir, ".mcp.json") if mcp_dir else Path(".mcp.json")
    result = extract([Path("main.py"), rel], root=Path("."), parallel=False)
    ids = {n["id"] for n in result["nodes"]}
    assert "mcp_command_npx" in ids  # guard: the ingest actually ran
    assert graph_has_legacy_ids(result["nodes"], root=".") is False


def test_semantic_rekey_relative_vs_absolute_source_file():
    """Re-key contract: a relative source_file is migrated; an absolute one is left
    untouched (it can't be relativized, so its on-disk path must not leak into IDs)."""
    from graphify.build import _semantic_id_remap
    rel = [{"id": "api_readme", "source_file": "docs/v1/api/README.md", "type": "document"}]
    assert _semantic_id_remap(rel, ".") == {"api_readme": "docs_v1_api_readme"}
    # absolute path with no resolvable root → skipped, not remapped to an abs-path id
    ab = [{"id": "api_readme", "source_file": "/abs/docs/v1/api/README.md", "type": "document"}]
    assert _semantic_id_remap(ab, None) == {}


def test_cross_language_imports_references_are_dropped():
    """#1749: an `imports`/`references` edge must not bind across a language
    family. A Python `import time` that resolved by bare stem onto a `time.ts`
    file node welds the two language halves together at a phantom edge; the spec
    forbids this for `calls` and it is equally invalid here."""
    ext = {
        "nodes": [
            {"id": "backend_worker_py", "label": "worker.py", "file_type": "code",
             "source_file": "backend/worker.py", "source_location": "L1", "_origin": "ast"},
            {"id": "src_time_ts", "label": "time.ts", "file_type": "code",
             "source_file": "src/time.ts", "source_location": "L1", "_origin": "ast"},
            {"id": "src_util_ts", "label": "util.ts", "file_type": "code",
             "source_file": "src/util.ts", "source_location": "L1", "_origin": "ast"},
        ],
        "edges": [
            # phantom: Python file importing a TS file (cross-language)
            {"source": "backend_worker_py", "target": "src_time_ts", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "backend/worker.py", "weight": 1.0},
            # legit: TS importing TS (same family) must survive
            {"source": "src_time_ts", "target": "src_util_ts", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "src/time.ts", "weight": 1.0},
        ],
    }
    G = build_from_json(ext, directed=False)
    assert not G.has_edge("backend_worker_py", "src_time_ts"), "cross-language import must be dropped"
    assert G.has_edge("src_time_ts", "src_util_ts"), "same-family (TS->TS) import must survive"


def test_cross_family_reference_to_unknown_ext_is_kept():
    """The #1749 guard only drops when BOTH endpoints are known code languages,
    so a reference from a config/manifest (unknown ext) to a code file is kept."""
    ext = {
        "nodes": [
            {"id": "pkg_json", "label": "package.json", "file_type": "code",
             "source_file": "package.json", "source_location": "L1", "_origin": "ast"},
            {"id": "src_app_ts", "label": "app.ts", "file_type": "code",
             "source_file": "src/app.ts", "source_location": "L1", "_origin": "ast"},
        ],
        "edges": [
            {"source": "pkg_json", "target": "src_app_ts", "relation": "references",
             "confidence": "EXTRACTED", "source_file": "package.json", "weight": 1.0},
        ],
    }
    G = build_from_json(ext, directed=False)
    assert G.has_edge("pkg_json", "src_app_ts"), "config->code reference (unknown ext) must be kept"


def test_markdown_doc_twin_merges_into_semantic_doc_node():
    """#1799: the markdown quick-scan's bare `<slug>` doc node and the semantic
    `<slug>_doc` node for the same file must collapse to one node, with edges
    consolidated — otherwise a document is two disconnected halves and traversals
    dead-end on the wrong twin."""
    ext = {
        "nodes": [
            {"id": "docs_readme_doc", "label": "README", "file_type": "document",
             "source_file": "docs/readme.md", "source_location": "L1"},
            {"id": "docs_readme", "label": "readme.md", "file_type": "document",
             "source_file": "docs/readme.md", "source_location": "L1"},
            {"id": "code_auth", "label": "auth", "file_type": "code",
             "source_file": "auth.py", "source_location": "L1"},
            {"id": "docs_guide", "label": "guide.md", "file_type": "document",
             "source_file": "docs/guide.md", "source_location": "L1"},
        ],
        "edges": [
            {"source": "docs_readme_doc", "target": "code_auth", "relation": "references",
             "source_file": "docs/readme.md", "confidence": "INFERRED", "weight": 1.0},
            {"source": "docs_guide", "target": "docs_readme", "relation": "references",
             "source_file": "docs/guide.md", "confidence": "EXTRACTED", "weight": 1.0},
        ],
    }
    G = build_from_json(ext, directed=False)
    assert "docs_readme" not in G.nodes()          # bare twin merged away
    assert "docs_readme_doc" in G.nodes()           # semantic node is canonical
    assert G.has_edge("docs_guide", "docs_readme_doc")   # quick-scan edge repointed
    assert G.has_edge("docs_readme_doc", "code_auth")    # semantic edge kept


def test_doc_twin_merge_does_not_touch_code_symbols():
    """#1799 guard: a code symbol `foo` and an unrelated `foo_doc` (not
    file_type=document) must NOT merge, even sharing a source_file."""
    ext = {
        "nodes": [
            {"id": "m_foo", "label": "foo", "file_type": "code",
             "source_file": "m.py", "source_location": "L1"},
            {"id": "m_foo_doc", "label": "foo rationale", "file_type": "rationale",
             "source_file": "m.py", "source_location": "L2"},
        ],
        "edges": [],
    }
    G = build_from_json(ext, directed=False)
    assert {"m_foo", "m_foo_doc"} <= set(G.nodes())


def test_build_from_json_prunes_dangling_hyperedge_members(capsys):
    """#1916: build_from_json used to copy hyperedges into G.graph["hyperedges"]
    verbatim without validating members, so a dangling member reached graph.json
    even from a live (non-cache) extraction. Members absent from the built node
    set are pruned — matching how dangling pairwise edges are skipped — and a
    hyperedge with no surviving member is dropped whole."""
    ext = {
        "nodes": [
            {"id": "alpha", "label": "alpha", "file_type": "code", "source_file": "a.py"},
            {"id": "beta", "label": "beta", "file_type": "code", "source_file": "a.py"},
        ],
        "edges": [],
        "hyperedges": [
            {"id": "he_partial", "nodes": ["alpha", "beta", "ghost_member"], "source_file": "a.py"},
            {"id": "he_all_ghost", "nodes": ["ghost1", "ghost2"], "source_file": "a.py"},
        ],
    }
    G = build_from_json(ext)
    hes = {h["id"]: h for h in G.graph.get("hyperedges", [])}
    assert set(hes) == {"he_partial"}, "an all-dangling hyperedge must be dropped"
    assert hes["he_partial"]["nodes"] == ["alpha", "beta"]
    assert "he_all_ghost" in capsys.readouterr().err


# --- foreign-absolute source_file must not leak into IDs --------------------
# A graph.json is portable: built in Docker/Linux CI, updated on a Windows
# workstation, or the reverse. Every guard that asks "is this stored path
# absolute?" therefore has to answer for BOTH platforms. Host-only tests
# (Path.is_absolute / os.path.isabs) silently call the other platform's
# absolute paths relative, which bakes a build directory into node IDs (the
# mirror of #2197, reported as #2618) or joins it under the scan root.
#
# os.path.isabs is doubly unsafe here: Python 3.13 changed ntpath.isabs so a
# single leading slash is no longer absolute, where 3.10-3.12 said it was, so
# the same guard meant different things across supported interpreters.

FOREIGN_ABSOLUTE_SOURCE_FILES = [
    "/home/ci/build/repo/docs/api/README.md",   # POSIX-absolute (Linux/Docker build)
    "C:/Users/u/repo/docs/api/README.md",       # Windows-absolute, forward slashes
]


@pytest.mark.parametrize("sf", FOREIGN_ABSOLUTE_SOURCE_FILES)
def test_semantic_rekey_skips_absolute_from_either_platform(sf):
    """#2618: an absolute source_file is left alone whichever OS wrote it."""
    from graphify.build import _semantic_id_remap
    nodes = [{"id": "api_readme", "source_file": sf, "type": "document"}]
    assert _semantic_id_remap(nodes, None) == {}, (
        f"{sf!r} leaked its on-disk path into the node ID"
    )


@pytest.mark.parametrize("sf", FOREIGN_ABSOLUTE_SOURCE_FILES)
def test_graph_has_legacy_ids_skips_absolute_from_either_platform(sf):
    """The legacy-ID probe derives a stem from source_file, so it must skip an
    absolute path rather than mint a stem out of the whole build directory."""
    from graphify.build import graph_has_legacy_ids
    nodes = [{"id": "api_readme", "source_file": sf,
              "type": "document", "source_location": "L1"}]
    assert graph_has_legacy_ids(nodes, root=None) is False


def test_norm_source_file_relativizes_a_posix_absolute_path():
    """A Linux-built graph's absolute source_file must relativize against the
    matching root regardless of the host running the update."""
    from graphify.build import _norm_source_file
    assert _norm_source_file(
        "/home/ci/build/repo/docs/api/README.md", "/home/ci/build/repo"
    ) == "docs/api/README.md"


def test_build_from_json_relativizes_definition_file():
    """A merged C/C++/ObjC decl/def node records where the symbol is implemented
    in `definition_file`. That is a path into the scanned tree just like
    `source_file`, so the graph must store it repo-relative — otherwise the
    build machine's absolute path ships in graph.json and a reader on another
    checkout (or the MCP `get_node` answer) points at a file that is not there."""
    from graphify.build import build_from_json

    root = "/home/ci/build/repo"
    extraction = {
        "nodes": [{
            "id": "foo_bar",
            "label": "bar",
            "type": "function",
            "file_type": "code",
            "_origin": "ast",
            "source_file": f"{root}/src/Foo.h",
            "source_location": "L10",
            "definition_file": f"{root}/src/Foo.cpp",
            "definition_location": "L42",
        }],
        "edges": [],
    }
    G = build_from_json(extraction, root=root)
    assert G.nodes["foo_bar"]["source_file"] == "src/Foo.h"
    assert G.nodes["foo_bar"]["definition_file"] == "src/Foo.cpp"
    # the line number is a plain string and must survive untouched
    assert G.nodes["foo_bar"]["definition_location"] == "L42"


def test_derive_prune_root_recovers_root_from_posix_absolute_prune_sources():
    """The prune-root recovery skips any prune source it thinks is relative.

    With a host-only absoluteness test, every POSIX-absolute prune source was
    skipped on Windows, the root came back None, and prune/replace silently
    no-opped — the failure mode of #1151 / #2446 / #2012, reached from the other
    direction.
    """
    from graphify.build import _derive_prune_root
    stored = {"docs/a.md", "/home/ci/build/repo/docs/b.md"}
    assert _derive_prune_root(
        ["/home/ci/build/repo/docs/a.md"], stored
    ) == "/home/ci/build/repo"


# ── #3411: Cross-file stub nodes must not pollute AST replacement set ────────


def test_build_merge_sln_stub_does_not_replace_referenced_csproj(tmp_path):
    """#3411: Re-extracting a .sln must replace only the .sln's AST contribution.
    Cross-file project stubs (source_file='A/A.csproj') in the .sln chunk must not
    cause A/A.csproj's PackageReference/TargetFramework nodes and edges to be wiped."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    # Initial full extraction:
    # 1) A.csproj with framework, package reference, and internal edges
    # 2) A.sln containing A.csproj
    c_proj = {
        "nodes": [
            {"id": "a_a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
            {"id": "framework_net8_0", "label": "net8.0", "file_type": "concept",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
            {"id": "nuget_newtonsoft_json", "label": "Newtonsoft.Json (13.0.3)",
             "file_type": "code", "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_a_csproj", "target": "framework_net8_0", "relation": "references",
             "confidence": "EXTRACTED", "source_file": "A/A.csproj", "weight": 1.0, "_origin": "ast"},
            {"source": "a_a_csproj", "target": "nuget_newtonsoft_json", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "A/A.csproj", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": [str(root / "A" / "A.csproj")],
    }
    sln_initial = {
        "nodes": [
            {"id": "a_sln", "label": "A.sln", "file_type": "code",
             "source_file": "A.sln", "source_location": None, "_origin": "ast"},
            {"id": "a_a_csproj", "label": "A", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_sln", "target": "a_a_csproj", "relation": "contains",
             "confidence": "EXTRACTED", "source_file": "A.sln", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": [str(root / "A.sln")],
    }
    G0 = build([c_proj, sln_initial], dedup=False, root=root)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # Incremental update: ONLY A.sln is modified and re-extracted.
    # extract_sln produces the solution node AND a cross-file stub for A/A.csproj.
    sln_reextracted = {
        "nodes": [
            {"id": "a_sln", "label": "A.sln", "file_type": "code",
             "source_file": "A.sln", "source_location": None, "_origin": "ast"},
            {"id": "a_a_csproj", "label": "A", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_sln", "target": "a_a_csproj", "relation": "contains",
             "confidence": "EXTRACTED", "source_file": "A.sln", "weight": 1.0, "_origin": "ast"},
        ],
        # Explicit provenance: only A.sln was actually extracted
        "extracted_sources": [str(root / "A.sln")],
    }

    G1 = build_merge([sln_reextracted], graph_path, dedup=False, root=root)

    node_ids = set(G1.nodes())
    # 1. Solution node and project stub node are present
    assert "a_sln" in node_ids, "Solution node must be present"
    assert "a_a_csproj" in node_ids, "Project node must be present"
    # 2. PackageReference and TargetFramework nodes of A.csproj must SURVIVE
    assert "framework_net8_0" in node_ids, (
        "#3411 regression: TargetFramework node of referenced .csproj was wiped by .sln re-extraction"
    )
    assert "nuget_newtonsoft_json" in node_ids, (
        "#3411 regression: PackageReference node of referenced .csproj was wiped by .sln re-extraction"
    )
    # 3. Edges must SURVIVE
    assert G1.has_edge("a_sln", "a_a_csproj"), "sln contains edge must be present"
    assert G1.has_edge("a_a_csproj", "framework_net8_0"), (
        "#3411 regression: references edge to TargetFramework was wiped"
    )
    assert G1.has_edge("a_a_csproj", "nuget_newtonsoft_json"), (
        "#3411 regression: imports edge to PackageReference was wiped"
    )


def test_build_merge_project_reference_stub_does_not_replace_referenced_project(tmp_path):
    """#3411: Re-extracting B.csproj (which has a ProjectReference to A.csproj) must
    replace only B.csproj's AST contribution. A.csproj's PackageReference and
    TargetFramework nodes must remain intact."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    # Initial graph: A.csproj with package & framework; B.csproj referencing A.csproj
    c_proj_a = {
        "nodes": [
            {"id": "a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
            {"id": "framework_net8_0", "label": "net8.0", "file_type": "concept",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
            {"id": "nuget_pkg_a", "label": "PackageA (1.0.0)", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_csproj", "target": "framework_net8_0", "relation": "references",
             "confidence": "EXTRACTED", "source_file": "A/A.csproj", "weight": 1.0, "_origin": "ast"},
            {"source": "a_csproj", "target": "nuget_pkg_a", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "A/A.csproj", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": [str(root / "A" / "A.csproj")],
    }
    c_proj_b = {
        "nodes": [
            {"id": "b_csproj", "label": "B.csproj", "file_type": "code",
             "source_file": "B/B.csproj", "source_location": None, "_origin": "ast"},
            {"id": "b_old_symbol", "label": "old_fn", "file_type": "code",
             "source_file": "B/B.csproj", "source_location": "L10", "_origin": "ast"},
            {"id": "a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "b_csproj", "target": "b_old_symbol", "relation": "contains",
             "confidence": "EXTRACTED", "source_file": "B/B.csproj", "weight": 1.0, "_origin": "ast"},
            {"source": "b_csproj", "target": "a_csproj", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "B/B.csproj", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": [str(root / "B" / "B.csproj")],
    }
    G0 = build([c_proj_a, c_proj_b], dedup=False, root=root)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # Re-extract ONLY B.csproj (b_old_symbol replaced by b_new_symbol; ProjectReference stub to A.csproj emitted)
    c_proj_b_reextracted = {
        "nodes": [
            {"id": "b_csproj", "label": "B.csproj", "file_type": "code",
             "source_file": "B/B.csproj", "source_location": None, "_origin": "ast"},
            {"id": "b_new_symbol", "label": "new_fn", "file_type": "code",
             "source_file": "B/B.csproj", "source_location": "L12", "_origin": "ast"},
            {"id": "a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "b_csproj", "target": "b_new_symbol", "relation": "contains",
             "confidence": "EXTRACTED", "source_file": "B/B.csproj", "weight": 1.0, "_origin": "ast"},
            {"source": "b_csproj", "target": "a_csproj", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "B/B.csproj", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": [str(root / "B" / "B.csproj")],
    }

    G1 = build_merge([c_proj_b_reextracted], graph_path, dedup=False, root=root)

    node_ids = set(G1.nodes())
    # 1. B.csproj was replaced properly
    assert "b_new_symbol" in node_ids, "New symbol in B.csproj must be present"
    assert "b_old_symbol" not in node_ids, "Stale symbol in B.csproj must be dropped"
    # 2. A.csproj package & framework nodes must NOT be dropped
    assert "nuget_pkg_a" in node_ids, (
        "#3411 regression: PackageReference in referenced A.csproj was wiped when B.csproj was re-extracted"
    )
    assert "framework_net8_0" in node_ids, (
        "#3411 regression: TargetFramework in referenced A.csproj was wiped when B.csproj was re-extracted"
    )
    # 3. All edges survive
    assert G1.has_edge("a_csproj", "nuget_pkg_a")
    assert G1.has_edge("a_csproj", "framework_net8_0")
    assert G1.has_edge("b_csproj", "a_csproj")


def test_merge_raw_extraction_cross_file_stub_parity(tmp_path):
    """#3411: merge_raw_extraction shares the same explicit extraction provenance
    scoping as build_merge."""
    import networkx as nx
    from graphify.build import merge_raw_extraction

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    # Initial graph on disk
    c_proj = {
        "nodes": [
            {"id": "a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
            {"id": "nuget_pkg", "label": "PackageA", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_csproj", "target": "nuget_pkg", "relation": "imports",
             "confidence": "EXTRACTED", "source_file": "A/A.csproj", "weight": 1.0, "_origin": "ast"},
        ],
    }
    G0 = build([c_proj], dedup=False, root=root)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # Re-extract A.sln with cross-file stub for A.csproj
    sln_reextracted = {
        "nodes": [
            {"id": "a_sln", "label": "A.sln", "file_type": "code",
             "source_file": "A.sln", "source_location": None, "_origin": "ast"},
            {"id": "a_csproj", "label": "A", "file_type": "code",
             "source_file": "A/A.csproj", "source_location": None, "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_sln", "target": "a_csproj", "relation": "contains",
             "confidence": "EXTRACTED", "source_file": "A.sln", "weight": 1.0, "_origin": "ast"},
        ],
        "extracted_sources": ["A.sln"],
    }

    merged = merge_raw_extraction(sln_reextracted, graph_path=graph_path, root=root)
    merged_node_ids = {n["id"] for n in merged["nodes"]}

    assert "nuget_pkg" in merged_node_ids, (
        "#3411: raw incremental path wiped PackageReference from referenced .csproj"
    )
    assert any(
        e.get("source") == "a_csproj" and e.get("target") == "nuget_pkg"
        for e in merged["edges"]
    ), "#3411: raw incremental path wiped imports edge to PackageReference"


def test_build_merge_explicit_ast_sources_argument(tmp_path):
    """#3411: build_merge honors ast_sources argument when passed explicitly."""
    import networkx as nx

    root = tmp_path / "corpus"
    root.mkdir()
    graph_path = tmp_path / "graph.json"

    c_proj = {
        "nodes": [
            {"id": "a_csproj", "label": "A.csproj", "file_type": "code",
             "source_file": "A/A.csproj", "_origin": "ast"},
            {"id": "nuget_pkg", "label": "PackageA", "file_type": "code",
             "source_file": "A/A.csproj", "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_csproj", "target": "nuget_pkg", "relation": "imports",
             "source_file": "A/A.csproj", "_origin": "ast"},
        ],
    }
    G0 = build([c_proj], dedup=False, root=root)
    graph_path.write_text(json.dumps(nx.node_link_data(G0, edges="edges")), encoding="utf-8")

    # Chunk has nodes without 'extracted_sources' attached to chunk,
    # but ast_sources is provided explicitly to build_merge
    sln_chunk = {
        "nodes": [
            {"id": "a_sln", "label": "A.sln", "file_type": "code",
             "source_file": "A.sln", "_origin": "ast"},
            {"id": "a_csproj", "label": "A", "file_type": "code",
             "source_file": "A/A.csproj", "_origin": "ast"},
        ],
        "edges": [
            {"source": "a_sln", "target": "a_csproj", "relation": "contains",
             "source_file": "A.sln", "_origin": "ast"},
        ],
    }

    G1 = build_merge([sln_chunk], graph_path, dedup=False, root=root, ast_sources=["A.sln"])
    assert "nuget_pkg" in G1, "ast_sources explicit arg must protect undispatched A.csproj"


def test_build_annotations_all_resolve():
    # build.py imports every annotated name at module scope -- no TYPE_CHECKING-only
    # names -- so an unresolvable hint here means a missing import, not a lazy one.
    import inspect
    import typing

    from graphify import build as build_module

    unresolvable = []
    for name, obj in vars(build_module).items():
        if inspect.isfunction(obj) and obj.__module__ == build_module.__name__:
            try:
                typing.get_type_hints(obj)
            except NameError as exc:
                unresolvable.append(f"{name}: {exc}")
    assert not unresolvable, "\n".join(unresolvable)


def test_method_ghost_dedupe_and_alias_resolution_3705():
    from graphify.build import build_from_json

    extraction = {
        "nodes": [
            # AST node with class segment and leading dot
            {
                "id": "broker_mock_tda_mocktdaaccount_save_state",
                "label": ".save_state()",
                "file_type": "code",
                "source_file": "broker/mock_tda.py",
                "source_location": "L220",
                "_origin": "ast",
            },
            # Spec-conformant semantic ghost node (no class segment, no leading dot)
            {
                "id": "broker_mock_tda_save_state",
                "label": "save_state()",
                "file_type": "code",
                "source_file": "broker/mock_tda.py",
            },
            {
                "id": "doc_summary",
                "label": "Doc Summary",
                "file_type": "document",
                "source_file": "docs/summary.md",
            },
        ],
        "edges": [
            {
                "source": "doc_summary",
                "target": "broker_mock_tda_save_state",
                "relation": "references",
                "confidence": "INFERRED",
                "confidence_score": 0.85,
                "source_file": "docs/summary.md",
            }
        ],
    }
    G = build_from_json(extraction)
    # The ghost node should be removed/remapped into the canonical AST node
    assert "broker_mock_tda_save_state" not in G.nodes
    assert "broker_mock_tda_mocktdaaccount_save_state" in G.nodes
    assert G.has_edge("doc_summary", "broker_mock_tda_mocktdaaccount_save_state")


def test_method_ghost_ambiguous_same_name_in_one_file_is_not_merged_3705():
    """Two AST methods with the same name in the SAME file (different classes)
    are a genuine ambiguity: a spec-conformant ghost must NOT be remapped or
    aliased onto either one (#3705 follow-up guard). The single-candidate rule
    (len == 1) must skip the 2-candidate case and leave the ghost intact."""
    from graphify.build import build_from_json

    extraction = {
        "nodes": [
            {"id": "svc_a_save_state", "label": ".save_state()", "file_type": "code",
             "source_file": "svc.py", "source_location": "L10", "_origin": "ast"},
            {"id": "svc_b_save_state", "label": ".save_state()", "file_type": "code",
             "source_file": "svc.py", "source_location": "L40", "_origin": "ast"},
            # spec-conformant ghost that could match either — must stay unmerged
            {"id": "svc_save_state", "label": "save_state()", "file_type": "code",
             "source_file": "svc.py"},
            {"id": "doc", "label": "Doc", "file_type": "document", "source_file": "d.md"},
        ],
        "edges": [
            {"source": "doc", "target": "svc_save_state", "relation": "references",
             "confidence": "INFERRED", "confidence_score": 0.85, "source_file": "d.md"},
        ],
    }
    G = build_from_json(extraction)
    # Both AST methods survive distinctly; the ambiguous ghost is NOT merged into either.
    assert "svc_a_save_state" in G.nodes and "svc_b_save_state" in G.nodes
    assert "svc_save_state" in G.nodes, "ambiguous ghost must be left intact, not remapped"
    # And it must not have been aliased onto one of them (edge stays on the ghost).
    assert G.has_edge("doc", "svc_save_state")
    assert not G.has_edge("doc", "svc_a_save_state")
    assert not G.has_edge("doc", "svc_b_save_state")

