# Add this section to the root README.md master prompt

## Project-scoped Claude tooling — authoritative override

For this repository, reviewed `.claude/skills/<name>/SKILL.md` skills are **project-owned and preferred** over unspecified global skills. `README.md` remains the one authoritative project instructions document, and `narrative/` remains the one canonical story source. `docs/CLAUDE_TOOLKIT_SETUP.md` documents tooling mechanics only, not game design.

At every new environment bootstrap, discover and verify project skills and `.mcp.json`. Prefer Graphify for project dependency/context queries, Context7 for current framework documentation, UI/UX Pro Max for layout and interface quality, Ponytail for scope discipline and Chrome DevTools for browser inspection. Use applicable `phaser4-*`, `cloudflare-neon-liveops`, and `google-anime-media` skills for specialized tasks. Never apply Godot-specific instructions to the Phaser runtime.

Do not assume MCP tools are usable merely because `.mcp.json` exists; verify Graphify is installed and the graph built, that Chrome exists, and that Context7 connects. The 5 original ZIP archives need not be committed; the selected skill content and pinned MCP package versions are committed instead. Do not auto-enable executable hook scripts.

Additional skills must be proposed with source revision, license, use case, security review and compatibility evidence; the owner approves them before installation. Add approved skills to `.claude/skills/` and update `docs/TOOL_SOURCES.json` in a reviewable PR. Avoid conflicting global skills.
