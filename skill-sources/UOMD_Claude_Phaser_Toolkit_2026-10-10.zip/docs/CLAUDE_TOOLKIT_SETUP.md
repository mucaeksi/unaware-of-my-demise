# UOMD — Claude GitHub project toolkit

This is a curated, **project-scoped**, source-traceable Claude Code toolbox. Add these files **to the root of the correct GitHub branch**. The repository root README remains the project's sole development master prompt; `narrative/` remains the story source of truth. Do not erase an existing `README.md`.

## Included

- `.claude/skills/` — local skills auto-discovered by compatible Claude Code runtimes (including Ponytail, Graphify, UI/UX Pro Max, Context7, Chrome DevTools, custom Phaser 4 and live-service skills).
- `.mcp.json` — project-scoped Context7 HTTP, Chrome DevTools MCP and Graphify Python MCP configuration.
- `.claude/third-party-licenses/` — upstream legal notices.
- `scripts/verify-claude-toolkit.py` — static structure verification only.
- `scripts/check-agent-environment.sh` — environment report, does not install packages or hooks.
- `docs/TOOL_SOURCES.json` — upstream provenance including SHA-256 hashes of uploaded ZIPs.

## Before starting

1. Confirm the intended **GitHub branch contains `README.md` and `narrative/`**. The assistant previously observed an empty `main` branch on October 10, 2026: verify which branch is authoritative before merging.
2. Review the skill files and their license terms before trusting third-party instructions.
3. Make Node.js, Python 3.10+, and [uv](https://docs.astral.sh/uv/) available in the Claude execution environment. Chrome DevTools MCP also needs a compatible Chrome/Chromium browser. In managed cloud sandboxes, tool execution may be restricted.
4. Open the repository with Claude Code and approve project-level MCP configuration as prompted.
5. Run `python3 scripts/verify-claude-toolkit.py` to check file structure.
6. Build a Graphify graph for the repository before invoking its project MCP endpoint, since `graphify-out/graph.json` does not ship in this toolkit.
7. Verify actual Context7, Chrome DevTools and Graphify tool calls; configuration presence does not prove server readiness.

## Scope and installation

Project `.claude/skills` entries are available from the repo without global installation. `README.md` must instruct Claude to use relevant skills and not duplicate a global skill unnecessarily.

`.mcp.json` is only a **declaration** of MCP servers: the runtime needs network access, packages and sufficient permissions to start them. Context7 uses hosted HTTP, Chrome DevTools uses pinned npm, and Graphify uses pinned PyPI (`graphifyy[mcp]==0.9.84`) through `uv` with a local repository graph. Cold starts may download packages. Check actual versions and platform constraints in CI.

The bundled Ponytail **skills** are usable; its executable hooks are *not* silently enabled because their behavior and compatibility must be inspected before approval. A project setting for its hooks can be added after testing. Graphify's optional auto-index hooks are also not enabled.

UI/UX Pro Max bundles its own data and Python scripts. Its skill path was adjusted from the plugin install layout to project-local `${CLAUDE_SKILL_DIR}`.

We intentionally did **not** copy the five whole upstream repositories or original 54 MB ZIP archives into the game source repository.

## Additional Phaser skills

Custom checked-in skills cover Phaser 4 engine, deterministic 5v5 combat, Gothic game UI, chibi animation, cinematic narrative, mobile/browser QA, Cloudflare+Neon LiveOps, and Google anime media production. Before importing larger third-party Phaser packs, inspect licenses, hooks, release/version pin and APIs against the installed Phaser 4 version. A candidate to evaluate is [Yakoub-ai/phaser4-gamedev](https://github.com/Yakoub-ai/phaser4-gamedev); never enable its hooks without code review.

## First instructions to Claude

> Read root README.md and narrative/ indexes. Audit installed project skills and MCP endpoints. Run scripts/verify-claude-toolkit.py, then check missing runtimes and Graphify graph. Do not install arbitrary dependencies, enable third-party hooks, delete old code, generate paid assets or mutate production infrastructure without owner approval. Propose only evidence-based additional Phaser skills as a reviewable PR, with pinned sources and license notes. Then begin Phaser 4 cloud-preview foundation work.

## Security

Keep Google, Cloudflare, Neon and all signing credentials in managed secret stores. Never commit `.env`, keys, tokens, persistent browser profiles or authenticated Graphify caches. Make changes on feature branches with owner-reviewed PRs.
