#!/usr/bin/env python3
"""Non-executing structural validation for repo-local Claude skills and MCP config."""
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT / '.claude' / 'skills'
files = sorted(SKILLS.glob('*/SKILL.md'))
errors = []
if len(files) < 10:
    errors.append('Too few skills found: expected curated collection')
for p in files:
    txt = p.read_text(encoding='utf-8')
    if not txt.startswith('---\n') or not re.search(r'(?m)^name:\s*', txt) or not re.search(r'(?m)^description:\s*',txt):
        errors.append(f'{p}: missing YAML frontmatter or name/description')
    if any(x in txt for x in ['${CLAUDE_PLUGIN_ROOT}/.claude/skills/ui-ux-pro-max']):
        errors.append(f'{p}: unresolved plugin-only path')
    if len(txt) > 250_000:
        errors.append(f'{p}: excessive SKILL.md size')
try:
    config=json.loads((ROOT/'.mcp.json').read_text(encoding='utf-8'))
    assert set(config['mcpServers'])=={'context7','chrome-devtools','graphify'}
    assert 'mcp.context7.com' in config['mcpServers']['context7']['url']
except Exception as ex:
    errors.append(f'MCP config error: {ex}')
if not (ROOT / '.claude' / 'third-party-licenses').is_dir():
    errors.append('Third-party license collection missing')
print('skills:', len(files), 'MCP servers:',3)
if errors:
    print('\n'.join('FAIL: '+e for e in errors));sys.exit(1)
print('PASS: repository-local skill and MCP structure')
