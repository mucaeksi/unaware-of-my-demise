#!/usr/bin/env bash
set -euo pipefail
printf 'UOMD Claude project tool check\n'
for cmd in node npm npx python3 uv claude; do
  if command -v "$cmd" >/dev/null 2>&1; then printf '  %s: %s\n' "$cmd" "$(command -v "$cmd")"
  else printf '  %s: MISSING\n' "$cmd"; fi
done
python3 scripts/verify-claude-toolkit.py
printf '\nGraphify graph: '
if [ -f graphify-out/graph.json ]; then echo READY; else echo 'MISSING (run graphify on the repository before using Graphify MCP)'; fi
printf 'Chrome: '
if command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1; then echo 'local browser detected'; else echo 'browser needs provision for DevTools MCP';fi
printf 'This script does not install programs or execute hooks.\n'
