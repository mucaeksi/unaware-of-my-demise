import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import * as jose from "jose";

vi.mock("jose", async () => {
  const actual = await vi.importActual<typeof jose>("jose");
  return {
    ...actual,
    createRemoteJWKSet: vi.fn(
      () => "fake-jwks" as unknown as ReturnType<typeof jose.createRemoteJWKSet>
    ),
    jwtVerify: vi.fn(),
  };
});

const TENANT_ID = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
const ENTRA_ISSUER = `https://login.microsoftonline.com/${TENANT_ID}/v2.0`;
const AUDIENCE = "6ff6a635-03d9-472d-a7f1-dc98a4e5fde2";
const originalOAuthAuthServerUrl = process.env.OAUTH_AUTH_SERVER_URL;
const originalOAuthJwksUrl = process.env.OAUTH_JWKS_URL;
const VERCEL_ISSUER = "https://integrations.vercel.com/oac_123456789";
const VERCEL_AUDIENCE = "https://integrations.vercel.com/context7/icfg_1234567890";

async function loadModule() {
  vi.resetModules();
  return import("../src/lib/jwt.js");
}

function makeFetchResponse(init: Partial<Response> & { jsonData?: unknown }): Response {
  const { jsonData, ...rest } = init;
  return {
    ok: true,
    status: 200,
    json: async () => jsonData,
    ...rest,
  } as Response;
}

function makeEntraToken(payload: jose.JWTPayload, typ = "JWT"): string {
  const header = Buffer.from(JSON.stringify({ alg: "RS256", typ })).toString("base64url");
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${header}.${body}.signature`;
}

function makeClerkToken(payload: jose.JWTPayload, typ = "at+jwt"): string {
  return makeEntraToken({ aud: "https://mcp.context7.com/mcp", ...payload }, typ);
}

const CLERK_VERIFY_OPTIONS = {
  issuer: "https://clerk.context7.com",
  typ: "at+jwt",
  clockTolerance: 60,
};

beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn());
  vi.stubEnv("VERCEL_MARKETPLACE_OIDC_ISSUER", VERCEL_ISSUER);
  vi.stubEnv("VERCEL_MARKETPLACE_OIDC_AUDIENCE", VERCEL_AUDIENCE);
});

afterEach(() => {
  if (originalOAuthAuthServerUrl === undefined) {
    delete process.env.OAUTH_AUTH_SERVER_URL;
  } else {
    process.env.OAUTH_AUTH_SERVER_URL = originalOAuthAuthServerUrl;
  }
  if (originalOAuthJwksUrl === undefined) {
    delete process.env.OAUTH_JWKS_URL;
  } else {
    process.env.OAUTH_JWKS_URL = originalOAuthJwksUrl;
  }
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.clearAllMocks();
});

describe("isJWT", () => {
  test("returns true for 3-part dotted strings", async () => {
    const { isJWT } = await loadModule();
    expect(isJWT("a.b.c")).toBe(true);
  });

  test("returns false for non-JWT strings", async () => {
    const { isJWT } = await loadModule();
    expect(isJWT("not-a-jwt")).toBe(false);
    expect(isJWT("only.two")).toBe(false);
    expect(isJWT("a.b.c.d")).toBe(false);
  });
});

describe("validateJWT - Entra path", () => {
  test("validates token after fetching tenant config", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(
      makeFetchResponse({
        jsonData: { teamspaceId: "team-1", tenantId: TENANT_ID, requiredScope: "mcp.access" },
      })
    );
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { oid: "user-oid", scp: "mcp.access" },
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const result = await validateJWT(makeEntraToken({ iss: ENTRA_ISSUER, aud: AUDIENCE }));

    expect(result.valid).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(fetchMock.mock.calls[0][0]).toContain(`/v2/entra/config/${AUDIENCE}`);
  });

  test("returns 'Unknown audience' when config endpoint returns 404", async () => {
    vi.mocked(fetch).mockResolvedValue(makeFetchResponse({ ok: false, status: 404 }));

    const { validateJWT } = await loadModule();
    const result = await validateJWT(makeEntraToken({ iss: ENTRA_ISSUER, aud: "unknown-aud" }));

    expect(result.valid).toBe(false);
    expect(result.error).toBe("Unknown audience");
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("returns 'Missing required scope' when scp claim lacks the configured scope", async () => {
    vi.mocked(fetch).mockResolvedValue(
      makeFetchResponse({
        jsonData: { teamspaceId: "team-1", tenantId: TENANT_ID, requiredScope: "mcp.access" },
      })
    );
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { scp: "other.scope" },
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const result = await validateJWT(makeEntraToken({ iss: ENTRA_ISSUER, aud: AUDIENCE }));

    expect(result.valid).toBe(false);
    expect(result.error).toBe("Missing required scope");
  });

  test("returns 'Missing audience' for Entra issuer with no aud claim", async () => {
    const { validateJWT } = await loadModule();
    const result = await validateJWT(makeEntraToken({ iss: ENTRA_ISSUER }));

    expect(result.valid).toBe(false);
    expect(result.error).toBe("Missing audience");
    expect(fetch).not.toHaveBeenCalled();
  });

  test("caches config across repeated audiences", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      makeFetchResponse({
        jsonData: { teamspaceId: "team-1", tenantId: TENANT_ID, requiredScope: null },
      })
    );
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { oid: "u" },
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: ENTRA_ISSUER, aud: AUDIENCE });
    await validateJWT(token);
    await validateJWT(token);

    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  test("does not cache transient 500 errors — next request retries", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(makeFetchResponse({ ok: false, status: 500 }));
    fetchMock.mockResolvedValueOnce(
      makeFetchResponse({
        jsonData: { teamspaceId: "team-1", tenantId: TENANT_ID, requiredScope: null },
      })
    );
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { oid: "u" },
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: ENTRA_ISSUER, aud: AUDIENCE });

    const first = await validateJWT(token);
    expect(first.valid).toBe(false);
    expect(first.error).toBe("Unknown audience");

    const second = await validateJWT(token);
    expect(second.valid).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});

describe("validateJWT - Clerk path", () => {
  test("verifies a Clerk access token against the Clerk JWKS without any fetch", async () => {
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { aud: "https://mcp.context7.com/mcp" },
      protectedHeader: { alg: "RS256", typ: "at+jwt" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const token = makeClerkToken({ iss: "https://clerk.context7.com" });
    const result = await validateJWT(token);

    expect(result).toEqual({ valid: true });
    expect(fetch).not.toHaveBeenCalled();
    expect(jose.jwtVerify).toHaveBeenCalledWith(token, "fake-jwks", CLERK_VERIFY_OPTIONS);
  });

  test("returns 'Token expired' when jwtVerify throws JWTExpired", async () => {
    vi.mocked(jose.jwtVerify).mockRejectedValue(
      new jose.errors.JWTExpired("expired", { payload: {}, protectedHeader: { alg: "RS256" } })
    );

    const { validateJWT } = await loadModule();
    const result = await validateJWT(makeClerkToken({ iss: "https://clerk.context7.com" }));

    expect(result.valid).toBe(false);
    expect(result.error).toBe("Token expired");
  });

  test("rejects Clerk ID tokens and session JWTs before any key lookup", async () => {
    const { validateJWT } = await loadModule();

    for (const typ of ["JWT", "jwt", undefined]) {
      const result = await validateJWT(makeEntraToken({ iss: "https://clerk.context7.com" }, typ));
      expect(result).toEqual({ valid: false, error: "Not an OAuth access token" });
    }
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("rejects JWTs from an untrusted issuer without a key lookup", async () => {
    const { validateJWT } = await loadModule();

    await expect(validateJWT(makeClerkToken({ iss: "https://evil.example" }))).resolves.toEqual({
      valid: false,
      error: "Untrusted issuer",
    });
    await expect(validateJWT(makeClerkToken({}))).resolves.toEqual({
      valid: false,
      error: "Untrusted issuer",
    });
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("uses the configured OAuth issuer and its JWKS for verification", async () => {
    process.env.OAUTH_AUTH_SERVER_URL = "https://supreme-foal-19.clerk.accounts.dev/";
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: { aud: "https://mcp.context7.com/mcp" },
      protectedHeader: { alg: "RS256", typ: "at+jwt" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const result = await validateJWT(
      makeClerkToken({ iss: "https://supreme-foal-19.clerk.accounts.dev" })
    );

    expect(result).toEqual({ valid: true });
    expect(jose.createRemoteJWKSet).toHaveBeenCalledWith(
      new URL("https://supreme-foal-19.clerk.accounts.dev/.well-known/jwks.json")
    );
    expect(jose.jwtVerify).toHaveBeenCalledWith(expect.any(String), "fake-jwks", {
      ...CLERK_VERIFY_OPTIONS,
      issuer: "https://supreme-foal-19.clerk.accounts.dev",
    });
  });

  test("allows an explicit JWKS URL without changing the OAuth issuer", async () => {
    process.env.OAUTH_AUTH_SERVER_URL = "https://oauth.example.com";
    process.env.OAUTH_JWKS_URL = "https://keys.example.com/oauth/jwks.json";

    await loadModule();

    expect(jose.createRemoteJWKSet).toHaveBeenCalledWith(
      new URL("https://keys.example.com/oauth/jwks.json")
    );
  });
});

describe("validateJWT - Vercel Marketplace OIDC path", () => {
  test("verifies the exact issuer, audience, time window, and resource", async () => {
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: {
        resource: "teamspace-resource-123",
        sub: "user_123",
        act: "owner:team1:project:p1:environment:production",
      },
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: VERCEL_ISSUER, aud: VERCEL_AUDIENCE });

    await expect(validateJWT(token)).resolves.toEqual({ valid: true });
    expect(jose.createRemoteJWKSet).toHaveBeenCalledWith(
      new URL(`${VERCEL_ISSUER}/.well-known/jwks`)
    );
    expect(jose.jwtVerify).toHaveBeenCalledWith(token, "fake-jwks", {
      algorithms: ["RS256"],
      audience: VERCEL_AUDIENCE,
      issuer: VERCEL_ISSUER,
      clockTolerance: 60,
    });
  });

  test("does not trust lookalike Vercel hosts", async () => {
    const { validateJWT } = await loadModule();
    const token = makeEntraToken({
      iss: "https://integrations.vercel.com.attacker.test/oac_123456789",
    });

    await expect(validateJWT(token)).resolves.toEqual({
      valid: false,
      error: "Untrusted issuer",
    });
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("rejects tokens from another Vercel integration", async () => {
    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: "https://integrations.vercel.com/oac_987654321" });

    await expect(validateJWT(token)).resolves.toEqual({
      valid: false,
      error: "Untrusted Vercel Marketplace issuer",
    });
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("fails closed when Marketplace OIDC is not configured", async () => {
    vi.stubEnv("VERCEL_MARKETPLACE_OIDC_ISSUER", "");
    vi.stubEnv("VERCEL_MARKETPLACE_OIDC_AUDIENCE", "");

    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: VERCEL_ISSUER });

    await expect(validateJWT(token)).resolves.toEqual({
      valid: false,
      error: "Vercel Marketplace OIDC not configured",
    });
    expect(jose.jwtVerify).not.toHaveBeenCalled();
  });

  test("requires Vercel's immutable resource claim", async () => {
    vi.mocked(jose.jwtVerify).mockResolvedValue({
      payload: {},
      protectedHeader: { alg: "RS256" },
    } as unknown as Awaited<ReturnType<typeof jose.jwtVerify>>);

    const { validateJWT } = await loadModule();
    const token = makeEntraToken({ iss: VERCEL_ISSUER, aud: VERCEL_AUDIENCE });

    await expect(validateJWT(token)).resolves.toEqual({
      valid: false,
      error: "Missing Vercel Marketplace resource",
    });
  });
});
