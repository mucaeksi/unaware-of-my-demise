# Cloudflare Security Audit — verified installer bundle

Source: https://github.com/cloudflare/security-audit-skill  
Source commit: `c1c8a8c1471069fb0e188eeaff69b8e8db6564a8`  
License: MIT (included as `LICENSE`)

**IMPORTANT:** This bundle is a PINNED INSTALLER, not an offline copy of the skill files. The actual official 20-file skill (~315 KB) is downloaded over HTTPS **when the user or Claude runs the script**. It verifies every file's exact Git object SHA-1 and size before activating the skill. This ZIP does not automatically change GitHub or run third-party validators.

Installation from project directory, after extracting ZIP:

```bash
python3 cloudflare-security-audit-installer/install_security_audit.py --project-root .
python3 cloudflare-security-audit-installer/install_security_audit.py --project-root . --verify
```

After installation, Claude Code discovers `.claude/skills/security-audit/SKILL.md`. To actually conduct an audit, ask Claude to review the code for security issues. Do not execute the included upstream validator scripts unless their contents and execution context have been reviewed.

If using the separate UOMD ZIP bootstrap, do not put this extra ZIP directly in `skill-sources/` unless its SHA is added to the allowlist; place it in `skill-sources/extras/` or install via the commands above. This archive has **no automatic background installation**.
