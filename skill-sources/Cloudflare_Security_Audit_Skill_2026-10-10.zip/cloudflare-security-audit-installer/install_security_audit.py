#!/usr/bin/env python3
"""Install official Cloudflare Security Audit skill from immutable Git commit.
Only downloads source text and data. Never executes downloaded code.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, tempfile, urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
MANIFEST=json.loads((HERE/'manifest.json').read_text(encoding='utf-8'))

def blob_sha(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def check(target):
    missing=[]
    for name, entry in MANIFEST['files'].items():
        p=target/name
        if not p.is_file() or p.stat().st_size!=entry['size'] or blob_sha(p.read_bytes())!=entry['git_blob_sha1']:
            missing.append(name)
    return missing

def main():
    p=argparse.ArgumentParser(description='Pinned Cloudflare security-audit skill installer')
    p.add_argument('--project-root',default='.',help='Project directory with .claude/skills')
    p.add_argument('--verify',action='store_true',help='Only check current installation')
    p.add_argument('--force',action='store_true',help='Replace an existing installation after download/verification')
    args=p.parse_args()
    root=Path(args.project_root).expanduser().resolve()
    target=root/'.claude'/'skills'/'security-audit'
    if args.verify:
        failures=check(target)
        if failures: raise SystemExit('FAILED: '+', '.join(failures))
        print('PASS: 20 official files verified against pinned Git blob SHA-1')
        return
    if target.exists() and not args.force:
        raise SystemExit('Skill already exists; use --verify or --force to explicitly replace it.')
    root.mkdir(parents=True,exist_ok=True)
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=Path(tempfile.mkdtemp(prefix='.security-audit-staging-',dir=target.parent))
    try:
        sha=MANIFEST['commit']
        for name,entry in MANIFEST['files'].items():
            url=f'https://raw.githubusercontent.com/cloudflare/security-audit-skill/{sha}/skills/security-audit/{name}'
            request=urllib.request.Request(url,headers={'User-Agent':'UOMD-security-audit-installer/1.0'})
            with urllib.request.urlopen(request,timeout=30) as r:
                data=r.read(entry['size']+1)
            if len(data)!=entry['size'] or blob_sha(data)!=entry['git_blob_sha1']:
                raise RuntimeError(f'Integrity verification failed: {name}')
            (tmp/name).write_bytes(data)
        assert not check(tmp), 'Unexpected validation failure'
        old=None
        if target.exists():
            old=target.with_name(target.name+'.backup')
            if old.exists(): raise RuntimeError('Backup target already exists: '+str(old))
            target.rename(old)
        try: tmp.rename(target)
        except Exception:
            if old: old.rename(target)
            raise
        print('SUCCESS:',target,'(20 verified official source files)')
        if old: print('Previous skill backup:',old)
    finally:
        if tmp.exists(): shutil.rmtree(tmp)

if __name__=='__main__': main()
